/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

/**
 *
 * @author howard
 */
public class Ch12_9 {

    static void test1(){
        System.out.println("Step1");
        try{
            System.out.println("Step2");
        }finally{
            System.out.println("Step3");
        }
        System.out.println("Step4");        
    }
    
    static void test2(){
        System.out.println("Step1");
        try{
            System.out.println("Step2");
            if (true){
                return;
            }
        }finally{
            System.out.println("Step3");
        }
        System.out.println("Step4");
    }
    
      static void test3(){
          System.out.println("Strp 1");
          try{
           System.out.println("Strp 2");
           if (true) throw new Exception("");
          }catch(Exception ex){
              System.out.println("Strp 3");
          }finally{
             System.out.println("Strp 4");    
          }
          System.out.println("Strp 5");          
      }
         static void test4(){
             try{
              System.exit(0);
             }finally{
                 System.out.println("Strp 1");  
             }
         }
      
    public static void main(String[] args) {
       // test1();       
      // test2();
     // test3();
     test4();
    }
    
}
