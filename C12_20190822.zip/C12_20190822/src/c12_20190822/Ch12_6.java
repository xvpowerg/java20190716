/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 *
 * @author howard
 */
public class Ch12_6 {

    public static void main(String[] args) {
      
       Stream<String> st = Stream.of("Ken","Vivin","Lindy","Howard");
//       String names = st.collect(Collectors.joining(",") );
//       System.out.println(names);
        String name2 = st.collect(Collectors.joining(",", "組員名單:", ".") );
        System.out.println(name2);
        
        
        
    }
    
}
