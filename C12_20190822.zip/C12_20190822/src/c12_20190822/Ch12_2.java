/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.util.List;
import java.util.ArrayList;
/**
 *
 * @author howard
 */
public class Ch12_2 {

   
    public static void main(String[] args) {
        Item i1 = new Item("Mac book",100);
        i1.appendLocation("高雄");
        i1.appendLocation("台北");
        i1.appendLocation("台中");
        Item i2 = new Item("Mac mini",65);
        i2.appendLocation("高雄");
        i2.appendLocation("台中");
        Item i3 = new Item("iPad",71);
        i3.appendLocation("台中");
        
    List<Item> itemList = new ArrayList<>();
     itemList.add(i1);
     itemList.add(i2);
     itemList.add(i3);
     
     //itemList.stream().map(it->it.getName()).forEach(System.out::println);
//   long count =   itemList.stream().map(it->it.getLocation()).
//             map(st->st.filter(v->v.indexOf("高雄") > -1).findFirst().orElse("")).
//             filter(str->str.indexOf("高雄") >-1).count();
//     System.out.println(count);

//       long count2 = itemList.stream().flatMap(it->it.getLocation()).
//               filter((loc)->loc.indexOf("高雄") >-1).count();
//       System.out.println(count2);

     int sum = itemList.stream().mapToInt(it->it.getPrice()).sum();
     System.out.println(sum);
    }
    
}
