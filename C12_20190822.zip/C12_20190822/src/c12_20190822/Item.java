/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


public class Item {
    private String name;
    private int price;
    private List<String> location = new ArrayList<>();
    public Item(){
        
    }
    public Item(String name,int price){
        this.name = name;
        this.price = price;
    }
    public String getName(){
        return name;
    }
        public int getPrice(){
        return price;
    }
    public void appendLocation(String loc){
        location.add(loc);
    }
    public Stream<String> getLocation(){
        return this.location.stream();
    }
    
    public String toString(){
        return name+":"+price;
    }
}
