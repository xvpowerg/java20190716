/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
public class Ch12_7 {
  
    public static void main(String[] args) {
            File file = new File("c:\\javadir\\news.txt");
            File copyFile = new File("c:\\javadir\\news_copy.txt");
            System.out.println(file.exists());
            
            try{
                FileInputStream fins = new FileInputStream(file);
                FileOutputStream fout = new FileOutputStream(copyFile);
                
                int data = -1;
                while(  (data = fins.read())!= -1){
                    fout.write(data);
                    //System.out.println(data);
                }
                
            }catch(FileNotFoundException ex){
                    System.out.println(ex);
            }catch(IOException ex){
                System.out.println(ex);
            }
        
        
        
    }
    
}
