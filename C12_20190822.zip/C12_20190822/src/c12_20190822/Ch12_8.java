/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import java.io.FileOutputStream;
import java.io.OutputStream;

import java.io.FileNotFoundException;
import java.io.IOException;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;


public class Ch12_8 {
    public static void main(String[] args) {
        File file = new File("c:\\javadir\\myzip.zip");
        File copyFile = new File("c:\\javadir\\myzip_copy.zip");
         InputStream istr = null;
          OutputStream outstr = null;
        try{
             istr = 
                    new BufferedInputStream(new FileInputStream(file)) ;
             outstr = 
                    new BufferedOutputStream(new FileOutputStream(copyFile));
            int data = -1;
            while( (data = istr.read()) != -1){
                outstr.write(data);
            }
           
        }catch(FileNotFoundException fex){
            System.out.println(fex);
        }catch(IOException ex){
            System.out.println(ex);
        }finally{
            try{
                  outstr.close();
                  istr.close();  
            }catch(IOException ex){
                
            }
       
        }
        
    }
    
}
