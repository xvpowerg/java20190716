/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.Optional;
/**
 *
 * @author howard
 */
public class Ch12_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Item i1 = new Item("Mac book",100);     
        Item i2 = new Item("Mac mini",65);      
        Item i3 = new Item("iPad",71);        
        Item i4 = new Item("Apple TV",62);      
        Item i5 = new Item("Apple Pen",25);
       Item i6 = new Item("iPad Mini",65);      
      Item i7 = new Item("iPhone X",71);      
          ArrayList<Item> list = new ArrayList<>();
          list.add(i1);
          list.add(i2);
          list.add(i3);
          list.add(i4);
          list.add(i5);
          list.add(i6);
          list.add(i7);
      Map<Integer,List<Item>> groupMap =  
              list.stream().
          collect(Collectors.groupingBy(it->it.getPrice() /10));
          System.out.println(groupMap);
      
//      TreeMap<Integer,Optional<Item>> ob = list.stream().collect(
//                  Collectors.groupingBy(it->it.getPrice() /10,TreeMap::new,
//                          Collectors.maxBy((v1,v2)->v1.getName().
//                                  compareTo(v2.getName()))));
//           System.out.println(ob);

//Map<Integer,ArrayList<String>> map1= list.stream().collect(Collectors.toMap(it->it.getPrice() / 10,
//        it->{
//            ArrayList<String> tmpList = new ArrayList();
//            tmpList.add(it.getName());
//            return tmpList;
//            },
//          (ov,nv)->{
//              ov.addAll(nv);
//               return ov;
//          }));
//System.out.println(map1);

// Map<Integer,List<String>>  map2= list.stream().collect(Collectors.groupingBy(it->it.getPrice()/10, 
//        TreeMap::new,
//        Collectors.mapping(it->it.getName(), Collectors.toList())));
// System.out.println(map2);

Map<Boolean,List<Item>>  map3 =  
        list.stream().collect(Collectors.partitioningBy((it)->it.getPrice() > 70));
System.out.println(map3);
  
 
    }
    
}
