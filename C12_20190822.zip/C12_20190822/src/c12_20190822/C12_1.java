/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;
import java.util.Optional;
public class C12_1 {
    private static String getString(){
        java.util.Random ran = new java.util.Random();
        StringBuffer sb= new StringBuffer();
        for (int i =1 ;i<=10 ;i++ ){
          char tmpChar = (char)(ran.nextInt(26)+'A');
          sb.append(tmpChar);
        }
        return sb.toString();
    }
    
    public static void main(String[] args) {
    Optional<String> option = Optional.ofNullable(null);
    String value1 =  option.orElse("Empty");
    System.out.println(value1);
    value1 =option.orElseGet(C12_1::getString);
     System.out.println(value1);
     option.orElseThrow(IllegalArgumentException::new);
    }
    
}
