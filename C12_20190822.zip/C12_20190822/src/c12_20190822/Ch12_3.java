/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.TreeSet;
public class Ch12_3 {
    
    public static void main(String[] args) {
      ArrayList<String> list = new ArrayList<>();
        list.add("Vivin");
        list.add("Ken");
        list.add("William");
        list.add("Tom");
        list.add("Iris");
        list.add("Howard");
    
        
       // list.stream().filter((n)->n.length() > 3).forEach(System.out::println);
//        List<String> nameList = list.stream().filter((n)->n.length() > 3).
//                collect(Collectors.toList());
//        nameList.forEach(System.out::println);
//    Set<String> set = 
//         list.stream().filter((v)->v.indexOf("i") > -1).collect(Collectors.toSet());
//     set.forEach(System.out::println);
     TreeSet<String> treeSet = list.stream().filter((n)->n.endsWith("m")).
             collect(Collectors.toCollection(TreeSet::new));
     treeSet.forEach(System.out::println);
     
        
    }
    
}
