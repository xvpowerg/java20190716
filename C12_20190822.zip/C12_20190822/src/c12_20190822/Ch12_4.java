/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package c12_20190822;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 *
 * @author howard
 */
public class Ch12_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Item i1 = new Item("Mac book",100);     
        Item i2 = new Item("Mac mini",65);      
        Item i3 = new Item("iPad",71);        
        Item i4 = new Item("Apple TV",62);      
        Item i5 = new Item("Apple Pen",25);
       Item i6 = new Item("iPad Mini",65);      
      Item i7 = new Item("iPhone X",71);      
          ArrayList<Item> list = new ArrayList<>();
          list.add(i1);
          list.add(i2);
          list.add(i3);
          list.add(i4);
          list.add(i5);
          list.add(i6);
          list.add(i7);
//     TreeSet<Item> set=    list.stream().filter((it)->it.getPrice() >25).
//                  collect(Collectors.toCollection(()->new TreeSet<Item>(Comparator.
//                          <Item,Integer>comparing((i)->i.getPrice()))));
//     set.forEach(System.out::println);
//  Map<Integer,String>  myMap =  
//          list.stream().collect(Collectors.toMap((it)->it.getPrice(), (it)->it.getName()));
//  myMap.forEach((k,v)->System.out.println(k+":"+v));

     TreeMap<Integer,String> treeMap =   list.stream().collect(Collectors.toMap(it->it.getPrice(),
                it->it.getName(), 
                (oldV,newV)->oldV+","+newV , TreeMap::new));
     System.out.println(treeMap);
     
        Optional<Item>  maxItem = list.stream().collect(Collectors.maxBy(Comparator.
             <Item,Integer>comparing(it->it.getPrice())));
       // maxItem.ifPresent(System.out::println);
//   Optional<String> nameOpt =   maxItem.map((it)->it.getName());
//   nameOpt.ifPresent(System.out::println);
maxItem.map((it)->it.getPrice()).ifPresent(System.out::println);
    }
    
}
