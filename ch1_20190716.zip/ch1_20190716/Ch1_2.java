/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ch1_20190716;

/**
 *
 * @author howard
 */
public class Ch1_2 {
    public static void main(String[] args){
        //先乘除後加減
        int a1 = 2;
        int a2 = 5;
        System.out.println(a1 + a2);
        System.out.println(a1 - a2);
        System.out.println( a2 + a1 * a2 );
        
        System.out.println(a1 / a2);//整除整數 求商數 沒有小數點
        float f1 = a1;
        System.out.println(f1 / a2);//浮點數除法可取得小數點
        System.out.println(a1 % a2);//求餘數
        //餘數應用
        //N1 % N2 = A 可以說  N1可以無限大   N2 > A >=0
        long N1 = 673131231546454L;
        int N2 = 7;
        long A = N1 % N2;
        System.out.println(A);
        
      
        
    }
}
