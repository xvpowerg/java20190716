/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ch1_20190716;
public class Ch1_1 {
    //一個Java檔案要能執行 必須有一個main作為程式入口
  public static void main(String[] args){
      //輸出Ken文字
      System.out.println("Ken");
      System.out.print("Vivin");
      System.out.println("Lindy");
      //電腦內最小單位為bit//bit 0或1      
      //7 6 5 4 3 2 1 0   2的N次方
      //0 1 0 1 1 0 1 0 8個bit 為1個byte
      // 以上2進位  轉為10進位為90
      //宣告變數 告知記憶體要開放多少空間讓我存放
      //整數 
        /*byte 請記憶體開1個byte空間存放 -128~127 要記起來!!
         short 請記憶體開2個byte空間存放 -32768~32767
         int   請記憶體開4個byte空間存放 -2147483648~2147483647
         long  請記憶體開8個byte空間存放 */  
        //java 預設將所有整數數字視為int
          byte b1 = 25;
          System.out.println(b1);
          b1 = 71;//使用以宣告的變數
          short s1 = 175;
          System.out.println(s1);
          int price = 65920;
          System.out.println(price);
          long dataCount = 2147483642;
//          System.out.println("Long min"+Long.MIN_VALUE);
//          System.out.println("Long max"+Long.MAX_VALUE);
           System.out.println(dataCount);
          long myLong = 2147483648L;
          System.out.println(myLong);
          
      //浮點數 
      //預設情況下浮點數為double 8 byte 
      //float 類型為 4byte
      //大給小會有溢位
       float pi = 3.1415f;
        //N定義為 Java內所有可能的類型
        //文字 + N 會將文字與N串接再一起       
       System.out.println("圓周率:"+pi);
       double e = 2.71828;
       System.out.println("E:"+e);
      //文字 
        //字元 基本型態(primitive) 16bit 2byte 0~65535
        char item1 = '圓';
        System.out.println(item1);
        int number = item1;
        System.out.println(number);        
        char item2 = 65;
       System.out.println(item2);  
         //Character     
        //字串 非基本型態(references) 
        String name = "Vivin";
        String name2 = "Ken";
        System.out.println(name2.charAt(0));
        System.out.println(name2.charAt(1));
         System.out.println(name2.charAt(2));
      //字串比大小用字元比
      //字元來說 數字 < 大寫英文字母 < 小寫英文字母
      char c0 = '0';
      char c1 = 'A';
      char c2 = 'a';
      
      int n0 = c0;
      int n1 = c1;
      int n2 = c2;
      System.out.println(n0);
      System.out.println(n1);
      System.out.println(n2);
      //字串比大小
      String cmp1 = "Bacd";
      String cmp2 = "bacd";
      // cmp1 > cmp2 ?  沒有
      String cmp3 = "abcd";
      String cmp4 = "aBcd";
      // cmp3 > cmp4 ?  有
      String cmp5 = "20";
      String cmp6 = "30";
       // cmp6 > cmp5 ?  有
       String cmp7 = "200";
       String cmp8 = "30"; 
       // cmp7 > cmp8 ?  沒有
        String cmp9 = "aaa";
       String cmp10 = "aaaaa";
       // cmp10 > cmp9 ?  有
       //Java 預設都是由小到大排序 遞增排序ASC
       
      //邏輯
      boolean isOpen = true;
      boolean isCon = false;
      System.out.println(isOpen);
      System.out.println(isCon);
      
  }
}
