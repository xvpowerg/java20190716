/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Manager manager = new Manager();
       manager.setName("Join");
       manager.setAge(45);
       manager.setSalary(65000);
       manager.print();
       
      Manager manager2 = new Manager("Tom",51,71000);
      manager2.print();
      
        Salesman salesman = new Salesman("Sean",25,45000);
      salesman.print();
     
    }
    
}
