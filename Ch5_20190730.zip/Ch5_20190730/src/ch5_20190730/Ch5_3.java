/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_3 {

    public static void main(String[] args) {
    
       // Test1 t1 = new Test1();
        Test2 t1 = new Test2(10,50);
    }
    
}
