/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Test2 extends Test1 {
    public Test2(){
        System.out.println("Test2()");
    }
    
    public Test2(int v1,float v2){
        this();
        System.out.println("Test2() int"+v1+" float:"+v2);
    }
    public Test2(int v1,byte v2){
        this();
       System.out.println("Test2() int"+v1+" byte:"+v2);
    }
}
