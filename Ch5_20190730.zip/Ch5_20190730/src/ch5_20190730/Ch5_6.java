/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_6 {
    public static void main(String[] args) {
        /*
            1 public
            2 protected
            3 預設
        　　4 private                        
        */
        Test3 t3 = new Test3();
         t3.testPublic();
         t3.testProtected();    
         t3.testDefault();
         
    }
    
}
