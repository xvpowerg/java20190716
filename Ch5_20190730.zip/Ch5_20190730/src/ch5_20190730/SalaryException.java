/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class SalaryException extends Exception{
     public SalaryException(){
        this("錯誤薪資");
    }
    public SalaryException(String msg){
        super(msg);
    }
}
