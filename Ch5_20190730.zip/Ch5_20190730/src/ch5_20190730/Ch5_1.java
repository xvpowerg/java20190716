/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_1 {

   
    public static void main(String[] args) {
    Employee emp1 = new Employee();
        emp1.setName("Ken");
        emp1.setAge(20);    
        emp1.setSalary(36000);
        
     Employee emp2 = new Employee();
     //emp2 = emp1;
        emp2.setName("Vivin");
        emp2.setAge(30);    
        emp2.setSalary(46000);        
        
    Employee emp3 = new Employee("Iris",27,52000);          
    Employee emp4 = new Employee();          
        emp1.print();
        emp2.print();
        emp3.print();
        
        emp4.print();
        
    }
    
}

