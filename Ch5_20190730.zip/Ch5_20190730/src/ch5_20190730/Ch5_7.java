/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_7 {

    public static void main(String[] args) {
//       String name = null;
//        name.toUpperCase();   
        
        String name = "";
        String price = " ";
    System.out.println("Out Step 1");
      String msg = "改變我";
        try{  System.out.println("Step 1");             
              name.toUpperCase();  
              Integer.parseInt(price);
              System.out.println("Step 2");            
        }catch(NullPointerException ex){
            System.out.println(ex);
        }catch(NumberFormatException ex){
              System.out.println(ex);
        }finally{
              System.out.println(msg);
        }
     System.out.println("Out Step 2"); 

        
    }
    
}
