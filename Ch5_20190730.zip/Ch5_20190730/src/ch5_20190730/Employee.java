/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;
//JavaBean 
public class Employee {
    private String name;
    private int age;
    private int salary;
    //Constructor 建構子　建構式
    //沒有回傳值
    //名稱跟類別一樣
    //可支持多載
    //預設建構子
    Employee(){
      
        //this.name = "空白未填寫";        
        // this()可呼叫目前類別其他的建構子
        //this() 只能是建構子的第一個命令
        this("空白未填寫",0,0);
          //System.out.println("Employee!!!");
    }
    Employee(String name,int age,int salary){
        this.name = name;
        this.age = age;
        this.salary = salary;
    }
    
    public void setName(String name){
        //1 this. 表示物件的東西
        //2 this. 為了能彈出提示
        this.name = name;        
    }
    public String getName(){
        return this.name;
    }
    public void setAge(int age){
        //不可小於18大於300
        this.age = age;
    }
    public int getAge(){
        return this.age;
    }
     public void setSalary(int salary)throws SalaryException{
         //　不大超過3_000_000　不可小於28000
         if (salary > 3_000_000 || salary < 28000){
             throw new SalaryException("不可大於3000000小於28000");
         }
        this.salary = salary;
    }
    public int getSalary(){
        return this.salary;
    }
    
    public void print(){
        System.out.println(this.getName()+":"+this.getAge()+":"+this.getSalary());
    }
}
