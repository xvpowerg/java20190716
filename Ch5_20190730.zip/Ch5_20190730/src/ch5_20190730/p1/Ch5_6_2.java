/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730.p1;
import ch5_20190730.Test3;
import ch5_20190730.Hero;
public class Ch5_6_2 {

    public static void main(String[] args) {
       Test3 t3_2 = new Test3();
        t3_2.testPublic();
        Hero h1 = new Hero();
        h1.testJump();
        
        ch5_20190730.p1.Hero hero2 = new  ch5_20190730.p1.Hero ();
        hero2.testRun();
        Test4 t4 = new Test4();
        t4.testProtected();
        
    }
    
}
//業務部 公開窗口
//研發 公開窗口
//人資 公開窗口
