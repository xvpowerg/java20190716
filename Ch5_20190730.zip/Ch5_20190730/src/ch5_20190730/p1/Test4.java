/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730.p1;
import ch5_20190730.Test3;
/**
 *
 * @author howard
 */
public class Test4  extends Test3{
   protected void testProtected(){
       System.out.println("Test4 testProtected!");
       super.testProtected();
   }
    public void test(){
       testProtected();
   }
   
}
