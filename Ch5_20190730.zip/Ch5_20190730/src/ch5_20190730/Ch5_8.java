/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

public class Ch5_8 {

   static void test1(){
       System.out.println("Step 1");
       try{
           System.out.println("in Step 1");
            if (true){
                return;
            }
            System.out.println("in Step 2");
       }finally{
           System.out.println("Step 2");
       }
   }
    public static void main(String[] args) {
        // TODO code application logic here
        test1();
    }
    
}
