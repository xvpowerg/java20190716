/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;
import java.sql.SQLException;
import java.io.FileNotFoundException;
/**
 *
 * @author howard
 */
public class Ch5_10 {
    public static void main(String[] args) {
//             try{
//           TestException texcp = new TestException();       
//            texcp.myException(1);    
//        }catch(SQLException ex){
//            System.out.println(ex);
//        }catch(FileNotFoundException ex){
//            System.out.println(ex);
//        }              
           try{
           TestException texcp = new TestException();       
            texcp.myException(1);    
        }catch(SQLException | FileNotFoundException ex){
            System.out.println(ex);
        }
           
           
           
    }
    
}
