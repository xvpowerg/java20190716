/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_4 {
    static void printEmployee(Employee mn){
        System.out.print("員工資訊：");
        mn.print();        
    }  
    public static void main(String[] args) {
      //多型　Polymorphism
      Employee tmp1 = new Manager("Vivin",34,65000);
      //tmp1.print();
      Employee tmp2 = new Salesman("Candy",21,26000);
      //tmp2.print();
//      printEmployee(tmp1);
        Manager manager = new Manager("Ken",34,65000);
        printEmployee(manager);
        Salesman sales = new Salesman("Sean",18,23000);
       printEmployee(sales);
    }
    
}
