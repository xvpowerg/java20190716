/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

public class Test3 {
    public void testPublic(){
        System.out.println("testPublic");
    }
    protected void testProtected(){
        System.out.println("testProtected");
    }
    void testDefault(){
         System.out.println("testDefault");
    }    
    private void testPrivate(){
        System.out.println("testPrivate");
    }
}
