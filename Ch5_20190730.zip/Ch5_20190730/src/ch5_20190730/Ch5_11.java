/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int a = 10;
        int b = 0;
        int c = a / b;
        TestException tex = new TestException();
        try{
            tex.myException2(9);
        }catch(IllegalArgumentException ex){
            System.out.println(ex);
        }

     
        
        
    }
    
}
