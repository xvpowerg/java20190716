/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.lang.ArithmeticException;
import java.lang.NullPointerException;
import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.IllegalArgumentException;
/**
 *
 * @author howard
 */
public class TestException {
    //例外有２種
    //1 必要例外檢測　強制險
    //　只要直接繼承Exception都是必要例外檢測
    //throws 定義可能拋出的例外
    //throw 拋出的例外
    public void myException(int v)throws SQLException,FileNotFoundException{
        if (v < 10){
            //拋出例外
            throw new SQLException();
        }else if(v < 20){
            throw new FileNotFoundException("檔案找不到!!");
        }
    }
    
    //2 非必要例外檢測 非強制險
    // 只要直接繼承RuntimeException都是非必要例外檢測
    public void myException2(int v){
        if (v < 10){
            throw new IllegalArgumentException("您數字小於10");
        }
        
    }
    
    
}
