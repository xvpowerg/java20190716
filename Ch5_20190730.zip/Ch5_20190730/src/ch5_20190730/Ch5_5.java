/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
public class Ch5_5 {

 
    public static void main(String[] args) {
       //字串所有方法都不會改變自己
        String str = "Abcdef";
        //把字串變大寫
        String str2 = str.toUpperCase();
        System.out.println(str);
        System.out.println(str2);
        
        System.out.println(str.compareTo("123"));
        System.out.println(str.compareTo("xyz"));
        System.out.println(str.compareTo(str));
    }
    
}
