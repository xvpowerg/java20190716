/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch5_20190730;

/**
 *
 * @author howard
 */
//繼承時Constructor不會被繼承
//繼承時private不會被繼承
public class Manager extends Employee{
    public Manager(){
        
    }
    public Manager(String name,int age,int salary){
        //super() 呼叫父類建構子
        //只能放在建構子的第一行命令
        super(name,age,salary);
//        this.setName(name);
//        this.setAge(age);
//        this.setSalary(salary);
    }
    
    public void print(){
        System.out.print("經理：");
        //super. 是呼叫父類別的方法
        super.print();
    }
}
