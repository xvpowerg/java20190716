/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;
public class Ch10_5 {
    public static void main(String[] args) {
       
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Ken",85);
        map.put("Vivin",92);
        map.put("Lindy",71);
        map.put("Vivin",67); 
        
        map.forEach((k,v)->System.out.println(k+":"+v));
        
        int score = map.get("Lindy");
        System.out.println(score);
        
        System.out.println(map.containsKey("Vivin"));
        System.out.println(map.containsKey("Tom"));
        
        System.out.println(map.containsValue(65));
         System.out.println(map.containsValue(67));
         
         Set<Entry<String,Integer>> entrySet =  map.entrySet();
         entrySet.forEach( (entry)->{
             System.out.println(entry.getKey()+":"+entry.getValue());         
         } );
         
         System.out.println(map.getOrDefault("Iris", 0));
         System.out.println(map.isEmpty());
         System.out.println(map.putIfAbsent("Ken", 79));
         System.out.println(map.get("Ken")); 
         System.out.println(map.putIfAbsent("Iris", 31));  
         System.out.println(map.get("Iris"));
         System.out.println("===================");
         map.remove("Vivin");
         map.forEach((k,v)->System.out.println(k+":"+v));
           System.out.println("===================");
           
        int canReplace = map.replace("Lindy", 150);
         System.out.println(canReplace);
           map.forEach((k,v)->System.out.println(k+":"+v));
          System.out.println("==================="); 
       //canReplace =  map.replace("Vivin", 21); 
       // System.out.println(canReplace);
    }
    
}

