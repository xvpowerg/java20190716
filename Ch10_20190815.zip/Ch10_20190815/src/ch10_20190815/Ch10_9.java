/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;
public class Ch10_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      TreeMap <Integer,String> treeMap = new TreeMap<>();
      treeMap.put(10, "Ken");
      treeMap.put(50, "Vivin");
      treeMap.put(20, "Lindy");
      treeMap.put(40, "Join");
      treeMap.forEach((k,v)->System.out.println(k+":"+v));
      
    Entry<Integer,String> centry = treeMap.ceilingEntry(30);//>=30
    Entry<Integer,String> hentry =treeMap.higherEntry(30);//>30
    System.out.println(centry.getKey()+":"+centry.getValue());
    System.out.println(hentry.getKey()+":"+hentry.getValue());
     
    centry = treeMap.ceilingEntry(20);//>=20
     hentry =treeMap.higherEntry(20);//>20
    System.out.println(centry.getKey()+":"+centry.getValue());
    System.out.println(hentry.getKey()+":"+hentry.getValue());
      
    Entry<Integer,String> fentry =   treeMap.floorEntry(20);//<=20
    Entry<Integer,String> loentry =  treeMap.lowerEntry(20);//<20
    System.out.println(fentry.getKey()+":"+fentry.getValue());
    System.out.println(loentry.getKey()+":"+loentry.getValue());
    
    //Key區間為 >= 10  < 40 的map
    Map<Integer,String> map = treeMap.subMap(10, 40);
    System.out.println(map);
    }
    
}
