/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.TreeMap;
import java.util.Comparator;
public class Ch10_10 {

    public static void main(String[] args) {
      
     MyKey key1 = new MyKey(10,"Key1");
     MyKey key2 = new MyKey(20,"Key2");
     MyKey key3 = new MyKey(30,"Key3");
     //TreeMap<MyKey,String> map = new TreeMap<>((k1,k2)->k1.getId() - k2.getId());
     TreeMap<MyKey,String> map = new TreeMap<>(Comparator.comparing(k->k.getId()));
     map.put(key1, "Apple");
     map.put(key2, "Banana");
     map.put(key3, "Kiwi");
     map.forEach((k,v)->System.out.println(k+":"+v));          

     
    }
    
}
