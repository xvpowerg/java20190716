/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;

/**
 *
 * @author howard
 */
public class Ch10_11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Student st1 = new Student("Ken",85);
      Student st3 = new Student("Lindy",83);
      Student st4 = new Student("Iris",51); 
      Student st6 = new Student("Vivin",92);
      //Map
//      5 Iris
//      8  Ken Lindy      
//      9 Vivin
    }
    
}
