 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author howard
 */
public class Ch10_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Student st1 = new Student("Ken",85);
      Student st2 = new Student("Vivin",73);
      Student st3 = new Student("Lindy",83);
      Student st4 = new Student("Iris",51);
      Student st5 = new Student("Ken",71);
      Student st6 = new Student("Vivin",92);
      ArrayList<Student> list = new ArrayList<>();
      list.add(st1);
      list.add(st2);
      list.add(st3);
      list.add(st4);
      list.add(st5);
      list.add(st6);
      
     HashMap<String,Integer> map = new HashMap<>();
     for(Student st : list){
         String key = st.getName();
         int score = st.getScore();
        if (map.containsKey(key)){
          score += map.get(key);
        } 
        map.put(key, score);
     }
     map.forEach((k,v)->System.out.println(k+":"+v));
      //如果key存在map 取出 並加上新的成績
        //再放回map
     //如果key不存在map 把新的Key與value新增入map    
                
       
    }
    
}
