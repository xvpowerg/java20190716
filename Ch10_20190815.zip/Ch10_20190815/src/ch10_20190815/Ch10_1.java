/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.TreeSet;
import java.util.Comparator;
import java.util.Scanner;

public class Ch10_1 {

    private static class BookComparator implements Comparator<Book>{
        public int compare(Book b1,Book b2){
            if (b1.getPrice() >b2.getPrice()){
                return 1;
            }else if(b1.getPrice() < b2.getPrice()){
                return -1;
            }else if(b1.getIsbn() > b2.getIsbn()){
                return 1;
            }else if(b1.getIsbn() < b2.getIsbn()){
                return -1;
            }
          return 0;
        }
    }
    
    private static class BookCompByISBN implements  Comparator<Book>{
            public int compare(Book b1,Book b2){
                if (b1.getIsbn() > b2.getIsbn()){
                    return 1;
                }else if(b1.getIsbn() < b2.getIsbn()){
                    return -1;
                }
                return 0;
            }
    }
    
    private static class BookCompByName implements Comparator<Book>{
        public int compare(Book b1,Book b2){
            int cmp = b1.getName().compareTo(b2.getName());
            
            if (cmp != 0){
                return cmp;
            }
            
            if (b1.getPrice() > b2.getPrice()){
                return 1;
            }else if(b1.getPrice() < b2.getPrice()){
                return -1;
            }else if(b1.getIsbn() > b2.getIsbn()){
                 return 1;
            }else if(b1.getIsbn() < b2.getIsbn()){
                return -1;
            }
            return 0;
        }
        
    }
    
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("1 金額 ISBN Name");
        System.out.println("2 ISBN ");
        System.out.println("3 Name 金額  ISBN   ");
        int type = scan.nextInt();
        
        Comparator bcpr = new BookComparator();
        switch(type){
            case 2:
              bcpr = new BookCompByISBN();
                break;
            case 3:
                bcpr = new BookCompByName();
        }
     TreeSet<Book> set = new TreeSet<>(bcpr);
        Book b1 = new Book("Andorid 開發手冊",300,10231);
        Book b2 = new Book("Swift練習",500,12345);
        Book b3 = new Book("Python演算法",300,1155);
        Book b4 = new Book("Golan 網路演算法",650,3126);
        
       set.add(b1);
       set.add(b2);
       set.add(b3);
       set.add(b4);
       
       set.forEach(System.out::println);
        
        
        
    }
    
}
