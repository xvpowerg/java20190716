/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.HashMap;
public class Ch10_6 {

    public static void main(String[] args) {
     HashMap<MyKey,String> myMap = new HashMap<>();
     MyKey key1 = new MyKey(10,"Key1");
     MyKey key2 = new MyKey(20,"Key2");
     MyKey key3 = new MyKey(30,"Key3");
     MyKey key4 = new MyKey(10,"Key1");
     
     myMap.put(key1, "Apple");
     myMap.put(key2, "Banana");
     myMap.put(key3, "Kiwi");
     myMap.put(key4, "Charry");
     
     myMap.forEach((k,v)->System.out.println(k+":"+v));
     
     
     
     
        
    }
    
}

