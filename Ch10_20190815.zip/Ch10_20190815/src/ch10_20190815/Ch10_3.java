/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;

import java.util.TreeSet;
import java.util.Comparator;
public class Ch10_3 {

    static int cmpBook(Book b1,Book b2){
        if (b1.getPrice() > b2.getPrice()){
            return 1;
        }else if(b1.getPrice() < b2.getPrice()){
            return -1;
        }else if(b1.getIsbn() > b2.getIsbn()){
            return 1;
        }else if(b1.getIsbn() < b2.getIsbn()){
            return -1; 
        }
        return 0;
    }
    
    public static void main(String[] args) {
//     TreeSet<Book> set = new TreeSet<>(Comparator.
//             <Book,Integer>comparing((b1)->b1.getPrice()).
//             thenComparing((b2)->b2.getIsbn()).reversed());
     
        TreeSet<Book> set = new TreeSet<>(Ch10_3::cmpBook);
        Book b1 = new Book("Andorid 開發手冊",300,10231);
        Book b2 = new Book("Swift練習",500,12345);
        Book b3 = new Book("Python演算法",300,1155);
        Book b4 = new Book("Golan 網路演算法",650,3126);
        
       set.add(b1);
       set.add(b2);
       set.add(b3);
       set.add(b4);
       
       set.forEach(System.out::println);
    }
    
}
