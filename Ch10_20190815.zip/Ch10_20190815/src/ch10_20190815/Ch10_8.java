/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author howard
 */
public class Ch10_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Student st1 = new Student("Ken",85);
      Student st2 = new Student("Vivin",73);
      Student st3 = new Student("Lindy",83);
      Student st4 = new Student("Iris",51);
      Student st5 = new Student("Ken",71);
      Student st6 = new Student("Vivin",92);
      
      ArrayList<Student> list = new ArrayList<>();
      list.add(st1);
      list.add(st2);
      list.add(st3);
      list.add(st4);
      list.add(st5);
      list.add(st6);
      HashMap<String,Integer> map2 = new HashMap<>(); 
      for (Student st :list){
          String key = st.getName();
          int score = st.getScore();
          map2.computeIfPresent(key, (k,v)->v+score);
          map2.computeIfAbsent(key, (k)->score);          
      }
      System.out.println(map2);
      
      HashMap<String,Integer> map = new HashMap<>(); 
     map.put("Ken",25);
     map.put("Vivin",70);
     //Key 存在
     //compute 會執行 並且覆蓋Key的value
     map.compute("Ken", (k,v)->{
         System.out.println(k+":"+v);
         return 30;
     });
     System.out.println(map);
     //如果Key存在不會執行 function
     map.computeIfAbsent("Ken",(key)->{
         System.out.println("computeIfAbsent...");
         return 95;});
   System.out.println(map);       
  //如果Key存在會執行 function 並且覆蓋Key的value
   map.computeIfPresent("Ken", (key,value)->{
       System.out.println(key+":"+value);
       return 62;
   });
   System.out.println(map);    
   
   System.out.println("===========不存在==============");     
   
        //Key 不存在
     //compute 會執行 並且新增Key與value
     map.compute("Iris", (k,v)->{
         //int kx = v;
         System.out.println(k+":"+v);
         return 30;
     });
     System.out.println(map);
     //會執行 並且新增Key與value
     map.computeIfAbsent("BoBo",(key)->{
         System.out.println("computeIfAbsent...");
         return 95;});
   System.out.println(map);       
  //不會執行
   map.computeIfPresent("Yumi", (key,value)->{
       System.out.println(key+":"+value);
       return 62;
   });
   System.out.println(map);   
   
   
   
    }
    
}

