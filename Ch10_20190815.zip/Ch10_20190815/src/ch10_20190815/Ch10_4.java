/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch10_20190815;
import java.util.Scanner;
import java.util.TreeSet;
import java.util.Comparator;
public class Ch10_4 {
    public static void main(String[] args) {
        TreeSet<Student> treeSet = new TreeSet<>(Comparator.<Student,Integer>comparing(st->st.getScore()).
                thenComparing(st->st.getName()).reversed());
       Scanner scan = new Scanner(System.in);
       for(int i =1;i<=5;i++){
           
           System.out.println("請輸入第"+i+"筆");
           System.out.println("請輸入姓名:");
           String name = scan.next();
          System.out.println("請輸入成績:");
          int score = scan.nextInt();         
          Student st = new Student(name,score);
          treeSet.add(st);
       }
       
       treeSet.forEach(System.out::println);
        
        
        
        
    }
    
}
