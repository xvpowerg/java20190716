/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;

public class Teacher {
    private String name;
    private int age;
    private int seniority;
    public Teacher(String name,int age,int seniority){
        this.name = name;
        this.age = age;
        this.seniority = seniority;
    }
    
    public String getName(){
        return name;
    }
    public int getAge(){
        return age;
    }
    public int getSeniority(){
        return seniority;
    }
    
    public String toString(){
        return String.format("姓名:%s 年齡:%d 年資:%d", 
                this.getName(),this.getAge(),this.getSeniority());
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Teacher == false){
            return false;
        }
        Teacher tmp = (Teacher)obj;
        
        return this.getName().equals(tmp.getName()) && 
                this.getAge() == tmp.getAge() && 
                this.getSeniority() == tmp.getSeniority();
    }
    
}
