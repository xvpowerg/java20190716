/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.HashSet;
public class Ch9_7 {
    public static void main(String[] args) {
//      HashSet<String> set = new HashSet<>();
//      set.add("B");
//      set.add("A");    
//      set.add("C");
//      set.add("A");
//      set.add("C");       
//      set.forEach(System.out::println);    
 HashSet<Item> itemSet = new HashSet<>();
        Item i1 = new Item("A",100);
        Item i2 = new Item("B",30);
        Item i3 = new Item("C",61);
        Item i4 = new Item("B",30);
        System.out.println(i4.equals(i2));
        itemSet.add(i1);
        itemSet.add(i2);
        itemSet.add(i3);
        itemSet.add(i4);
        itemSet.forEach(System.out::println);
        
    }
    
}

