/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.ArrayList;
public class Ch9_3 {

    public static void main(String[] args) {
//        ArrayList<Integer> list = new ArrayList<>();
//        list.add(10);
//        list.add(7);
//        list.add(2);
//        list.add(5);         
//        list.remove(Integer.valueOf(7));
//        list.forEach(System.out::println);
        
        Teacher t1 = new Teacher("Join",25,3);
        Teacher t2 = new Teacher("Ken",31,6);
        Teacher t3 = new Teacher("Iris",22,1);
        Teacher del = new Teacher("Ken",31,6); 
       System.out.println(del.equals(t2));
       ArrayList<Teacher> terList = new ArrayList<>();  
       terList.add(t1);
       terList.add(t2);
       terList.add(t3);
       terList.remove(del);
       System.out.println(terList);
       
       
       
    }
    
}
