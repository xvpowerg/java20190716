/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.TreeSet;
public class Ch9_8 {
    public static void main(String[] args) {
     TreeSet<Integer> treeSet = new TreeSet<>();
     treeSet.add(8);
     treeSet.add(1);
     treeSet.add(3);
     treeSet.add(5);
     treeSet.add(2);
     treeSet.forEach(System.out::println);
     System.out.println("=================");
     int x = 4;
    System.out.println(treeSet.floor(x ));//set內是否有<=x
    System.out.println(treeSet.lower(x));//set內是否有<x
    x = 1;
   System.out.println(treeSet.floor(x));//set內是否有<=x
    System.out.println(treeSet.lower(x));//set內是否有<x
     int y = 4;     
      System.out.println(treeSet.ceiling(y ));//set內是否有>=y
       System.out.println(treeSet.higher(y));//set內是否有>y
       y = 8;   
       System.out.println(treeSet.ceiling(y ));//set內是否有>=y
       System.out.println(treeSet.higher(y));//set內是否有>y   
    }
    
}

