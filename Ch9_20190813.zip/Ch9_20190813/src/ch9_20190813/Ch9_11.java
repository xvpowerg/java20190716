/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.TreeSet;
import tw.com.howard.Employee;
/**
 *
 * @author howard
 */
public class Ch9_11 {
    private static class MyEmployee extends Employee implements Comparable<MyEmployee>{
        public int compareTo(MyEmployee me){
                int cmp =  this.getName().compareTo(me.getName());
                if (cmp == 0){
                    if(this.getEmpId() > me.getEmpId()){
                            cmp = 1;
                    }else if(this.getEmpId() < me.getEmpId()){
                        cmp = -1;
                    }else if(this.getSalary() > me.getSalary()){
                        cmp = 1;
                    }else if(this.getSalary() < me.getSalary()){
                        cmp = -1;
                    }
                }
            return cmp;
        }
        public MyEmployee(String name,int id,int salary){
            super(name,id,salary);
        }
    }
     public static void main(String[] args) {
         Employee mp1 = new MyEmployee("Ken",100,25000);
         Employee mp2 = new MyEmployee("Vivin",200,26000);
         Employee mp3 = new MyEmployee("Vivin",210,29000);
         Employee mp4 = new MyEmployee("Iris",210,29000);
         Employee mp5 = new MyEmployee("Iris",210,25000);
         
         TreeSet<Employee> treSet = new TreeSet<>();
         treSet.add(mp1);
         treSet.add(mp2);
         treSet.add(mp3);
         treSet.add(mp4);
         treSet.add(mp5);
         treSet.forEach(System.out::println);
     }
}
