/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;

import java.util.LinkedList;

/**
 *
 * @author howard
 */
public class Ch9_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       LinkedList<String> names = new LinkedList<>();
       names.add("Ken");
       names.add("Join");
       names.add("Len");
       
      String peek =   names.peek();
      System.out.println(peek);
      peek =   names.peek();
      System.out.println(peek);
        
       String element = names.element();
       System.out.println(element);
       
       names.clear();
      peek =   names.peek();
      System.out.println(peek);
      element = names.element();
       System.out.println(element);
    }
    
}
