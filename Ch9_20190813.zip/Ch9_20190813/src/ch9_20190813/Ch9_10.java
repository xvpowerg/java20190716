/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.TreeSet;
public class Ch9_10 {
   public static void main(String[] args) {
       Item i1 = new Item("A",100);
        Item i2 = new Item("B",30);
        Item i3 = new Item("C",61);
        Item i4 = new Item("C",91);
        Item i5 = new Item("A",82);
        TreeSet<Item> set = new TreeSet<>();
        set.add(i1);
        set.add(i2);
        set.add(i3);
        set.add(i4);
        set.add(i5);
        set.forEach(System.out::println);
    }    
}
