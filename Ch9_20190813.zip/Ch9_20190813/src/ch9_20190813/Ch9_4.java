/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.LinkedList;
public class Ch9_4 {
    public static void main(String[] args) {
       LinkedList<String> names = new LinkedList<>();
       names.add("Ken");
       names.add("Join");
       names.add("Len");
       names.forEach(System.out::println);
         System.out.println("===============");
       String getName= names.remove();
       System.out.println(getName);
       getName = names.poll();
       System.out.println(getName);
      System.out.println("size:"+names.size());
//      names.remove();
//      names.remove();

      names.poll();
      System.out.println(names.poll());
      //會拋出例外組
       //names.add(e)
       //names.remove()
       //names.element();
       
      //會Return特別值
       //names.offer(e)
       //names.poll();
       //names.peek();
       
    }
    
}

