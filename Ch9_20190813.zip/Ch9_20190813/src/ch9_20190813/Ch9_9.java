/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;

import java.util.SortedSet;
import java.util.TreeSet;

/**
 *
 * @author howard
 */
public class Ch9_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TreeSet<Integer> treeSet = new TreeSet<>();
        treeSet.add(8);
        treeSet.add(1);
        treeSet.add(3);
        treeSet.add(5);
        treeSet.add(6);
        treeSet.add(2);
        treeSet.forEach(System.out::println);
        System.out.println("===============");
        SortedSet<Integer> subSet = treeSet.subSet(1, 7);
         System.out.println(subSet.size());
          System.out.println("===============");
          subSet.forEach(System.out::println);  
           System.out.println("===============");
          subSet = treeSet.subSet(3, 10);
         subSet.forEach(System.out::println);
         
//        System.out.println(treeSet.pollFirst());
//        System.out.println(treeSet.pollLast());
//        System.out.println(treeSet.size());
    }
    
}
