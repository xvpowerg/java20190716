/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;

import java.util.ArrayList;

/**
 *
 * @author howard
 */
public class Ch9_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           ArrayList<String> list = new ArrayList<>();
       list.add("Ken");
       list.add("Vivin");
       list.add("Join");
       list.add("Vivin");
       
       System.out.println(list.contains("Vivin"));
       System.out.println(list.contains("Gigi"));
       
        System.out.println(list.indexOf("Vivin"));
         System.out.println(list.indexOf("Gigi"));
         
         if (list.isEmpty()){
             System.out.println("空白的頁面");             
         }else{
             System.out.println("顯示畫面!!!");             
         }
         
       System.out.println(list.lastIndexOf("Vivin"));
       list.removeIf((n)->n.length() ==4);
       System.out.println("======================");
       list.forEach(n->System.out.println(n));
        System.out.println("======================");
       list.replaceAll((n)->"姓名:"+n);
        list.forEach(n->System.out.println(n));        
       System.out.println("======================");   
        list.set(2, "Mini");  
       list.forEach(n->System.out.println(n));        
         System.out.println("======================");   
      //String[] array = (String[])list.toArray();
      String[] array2 = {};
      array2 = list.toArray(array2);
      array2[0] = "Youme";
      for (String n :array2){
            System.out.println(n);
      }
      System.out.println(list.get(0));
    }
    
}
