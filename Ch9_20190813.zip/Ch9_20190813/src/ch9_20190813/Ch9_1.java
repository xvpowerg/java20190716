/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;
import java.util.ArrayList;
public class Ch9_1 {

   
    public static void main(String[] args) {
       ArrayList<String> list = new ArrayList<>();
       list.add("Ken");
       list.add("Vivin");
       list.add("Join");
       
       list.remove("Ken");       
       list.forEach((e)->{
       System.out.println(e);
       });
       System.out.println("===================");
       list.add(1, "Lindy");
       ArrayList<String> names = new ArrayList<>();
       names.add("Gigi");
       names.add("Kevn");
        names.add("Tom");
        //list.addAll(names);
        list.addAll(2,names);
         list.forEach((e)->{
       System.out.println(e);
       });
         System.out.println("===================");  
    }
    
}


