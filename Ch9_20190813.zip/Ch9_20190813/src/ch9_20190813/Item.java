/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch9_20190813;

/**
 *
 * @author howard
 */
public class Item implements Comparable<Item> {
    private String name;
    private int price;
    
    public int compareTo(Item it){
        //目前物件比傳入的大回傳正數
        //目前物件比傳入的小回傳負數
        //等於回傳零
            if (name.hashCode() > it.getName().hashCode()  ){
                return 1;
            }else if(name.hashCode() < it.getName().hashCode()){
                return -1;
            }else if(this.getPrice() > it.getPrice()){
                return 1;
            }else if(this.getPrice() < it.getPrice()){
                return -1;
            }
        return 0;
    }
    
    public Item(String name,int price){
        this.name = name;
        this.price = price;
    }
    
    public String getName(){
        return name;
    }
    public int getPrice(){
        return price;
    }
    public String toString(){
        return this.getName()+":"+this.getPrice();
    }
    
    public boolean equals(Object obj){
        if (obj == null || obj instanceof Item == false){
            return false;
        }
        Item tmpItem = (Item)obj;
        return this.getName().
                equals(tmpItem.getName()) && 
                tmpItem.getPrice() == this.getPrice();
    }
    
    public int hashCode(){
        return this.getName().hashCode() + this.getPrice();
    }
}
