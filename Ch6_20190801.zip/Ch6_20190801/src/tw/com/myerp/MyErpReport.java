/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.myerp;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;
public abstract class MyErpReport {
    private String[] readData(){
        String fileDir = "C:\\javadir\\reportdata.txt";
        ArrayList<String> list = new ArrayList<>();
        File file = new File(fileDir);
        try{
                FileReader fr = new FileReader(file);     
                BufferedReader bfr = new BufferedReader(fr);
                String data = null;
                while ( (data = bfr.readLine()) != null  ){
                    //System.out.println(data);
                    list.add(data);
                }
        }catch(FileNotFoundException ex){
            System.out.println(ex);
        }catch(IOException ex){
            System.out.println(ex);
        }
        String[] dataArray = {};
      dataArray =  list.toArray(dataArray);
        return dataArray;
    }
   
     public void exportReport(){
       String[] data =  readData();
       reportStyle(data);
    }
    
     protected abstract void reportStyle(String[] data);
    
    
}
