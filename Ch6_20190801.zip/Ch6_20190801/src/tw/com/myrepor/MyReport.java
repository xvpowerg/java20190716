/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.myrepor;
import tw.com.myerp.MyErpReport;
public class MyReport extends  MyErpReport{
    protected void reportStyle(String[] datas){
        for (String reportData :  datas){
            String[] showData =  reportData.split(",");
            System.out.printf("姓名:%s 第一季績效:%s "
                    + "第二季績效:%s 第三季績效:%s %n",
                    showData[0],
                    showData[1],
                    showData[2],
                    showData[3]);
        }
    }
  
}
