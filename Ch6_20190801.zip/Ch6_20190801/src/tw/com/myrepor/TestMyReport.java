/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tw.com.myrepor;

import tw.com.myerp.MyErpReport;

/**
 *
 * @author howard
 */
public class TestMyReport {


    public static void main(String[] args) {
        MyErpReport myReport = new MyReport();
        myReport.exportReport();
    }
    
}
