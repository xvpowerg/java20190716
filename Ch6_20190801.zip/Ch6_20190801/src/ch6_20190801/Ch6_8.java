/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_8 {
    public static void flyAction(Fly fly){
        fly.flying();
    }
    public static void main(String[] args) {
      
       Fly birdFly = new Bird();
       birdFly.flying();       
       Jump jump = new Bird();
       jump.jumping();
       
       Bird b3 =   new Bird();
       birdFly = b3;
       birdFly.flying();
       jump = b3;
       jump.jumping();
       
       flyAction(b3);
       //AirPlan  類別去實作 以下兩個介面
       //Run -->runing  Fly-->flying
       
    }
    
}
