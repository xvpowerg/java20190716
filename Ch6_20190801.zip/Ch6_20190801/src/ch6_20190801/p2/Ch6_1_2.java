/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801.p2;

/**
 *
 * @author howard
 */
public class Ch6_1_2 {

    public static void main(String[] args) {

            Test3 t3 = new Test3();
        t3.testPublic();
        t3.testProtected();
        t3.testDefault();
    }
    
}
