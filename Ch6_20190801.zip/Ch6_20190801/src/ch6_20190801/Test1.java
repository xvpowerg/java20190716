/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;
public class Test1 {
        
    /*
    Override 規則 
    1 讀取權限只能越來越開放 private 不算複寫
    2 回傳如果是基本型態必須一模一樣 
    3 回傳如果是物件型態可以一樣或子類型
    4 方法名稱與傳入參數類型必須一樣
    5 例外拋出可以是一樣或子類獲部拋出    
    */
    public void testPublic(){
        System.out.println("Test1 Public");        
    }    
    protected void  testProtected(){
       System.out.println("Test1 protected");   
    }
     void  testDefault(){
       System.out.println("Test1 Default");   
    }
      private void  testPrivate(){
       System.out.println("Test1 Private");   
    }
    //public
    //protected 
    //default
    //private
    
   public int testReturnInt(){
       return 10;
   }
   
 public Test1 testReturnObj(){
     return new Test1();
 }   
 
 public void test(Test1 test2){
     
 }
   public void testException() throws TestException1{
         
     }
}
