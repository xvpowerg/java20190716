/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //所有屬性或靜態的都是Shading(遮蔽)
        //遮蔽看類別
        //複寫看物件
//        TestShading1 test2 = new TestShading2();
//        test2.setValue(20);
//        test2.printValue();
//        test2.testStatic();

    TestShading1 test3 = new TestShading2();
    test3.value1 = 71;
    test3.printValue();
    test3.setValue2(10);
    test3.printValue2();
        
    }
    
}
