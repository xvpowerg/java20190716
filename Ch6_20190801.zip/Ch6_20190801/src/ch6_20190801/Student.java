/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Student {
    private String name;
    private int age;
    public Student(String name,int age){
        this.name = name;
        this.age = age;
    }
    
    public String toString(){
        return this.name+":"+this.age;
    }
    
    @Override
    public boolean equals(Object obj){
        
        if (obj == null || obj instanceof Student == false){
            return false;
        }
        Student tmpSt = (Student)obj;
        
        boolean result = this.age == tmpSt.age && this.name.equals(tmpSt.name);
        return result;
    }
    
}
