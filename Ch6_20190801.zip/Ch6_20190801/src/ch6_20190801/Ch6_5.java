/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TestBlock tb1 = new TestBlock();
        TestBlock tb2 = new TestBlock();
        
    }
    
}
