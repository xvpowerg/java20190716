/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class TestShading1 {
    public int value1;
    public int value2;
    
    public static void testStatic(){
        System.out.println("TestShading1");
    }
    
    public void setValue(int value){
        this.value1 = value;
    }
    
    public void printValue(){
        System.out.println("TestShading1:"+value1);
    }
    
    public void printValue2(){
        System.out.println("TestShading1:"+value2);
    }
    
    public void setValue2(int value2){
        this.value2  = value2;
    }
    
}
