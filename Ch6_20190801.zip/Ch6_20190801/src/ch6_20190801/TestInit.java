/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;
import java.util.Random;

public class TestInit {
    private int[] arrays = new int[20];
    private static String[] staticArray = new String[30];
    private int size =0;
    
    {
         Random random  = new Random();     
        for (int i =0;i< arrays.length;i++){
            int n = random.nextInt(5000);
            arrays[i] = n;
        }      
        
    }

  static{
      
       for (int i =0;i <staticArray.length;i++){
           staticArray[i] = "";
       }
      
  }
    
    public TestInit(int size){
        this.size = size;
    }
    
    public TestInit(){
       
    }
    public void print(){
        for (int v : arrays){
            System.out.println(v);
        }
    }
    public static void printStatic(){
           for (String v : staticArray){
               if (v.equals("A")){
                   System.out.println("是一樣的!!");
               }
            System.out.println(v);
        }
    }
    
}

