/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Test2  extends Test1{
    @Override
    public void testPublic(){
        System.out.println("Test2 testPublic");
    }
    
    protected void testProtected(){
         System.out.println("Test2 testProtected");
    }
    
    void testDefault(){
         System.out.println("Test2 testDefault");
    }
    
    private void testPrivate(){
         System.out.println("Test2 testPrivate");
    }
    
    public int testReturnInt(){
       return 10;
     }
      
    public Test2 testReturnObj(){
     return new Test2();
     }  
    
    @Override
    public void testException() throws TestException2{
         
     }

}
