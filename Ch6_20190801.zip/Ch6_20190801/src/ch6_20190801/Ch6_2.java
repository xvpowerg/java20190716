/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Student st1 = new Student("Ken",23);
            Student st2 = new Student("Ken",23);
            System.out.println(st1);
           String value = "學生:"+st1;
            System.out.println(value);
            
            System.out.println(st1.equals(st2));
            
        
    }
    
}
