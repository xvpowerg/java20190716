/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public interface Fly {
    //一般情況下 介面只有抽象方法
    //預設類型public abstract
    //public abstract void  flying();
     void flying();     
}
