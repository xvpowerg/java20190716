/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class TestBlock {
    {
       System.out.println("noneStatic Block 1");
    }
    static{
          System.out.println("Static Block 1");
    }
   public TestBlock(){
       System.out.println("Construct TestBlock");
   }
   
   {
         System.out.println("noneStatic Block 2");
   }
   
   static{
         System.out.println("Static Block 2");  
    }
   
}
