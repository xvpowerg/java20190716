/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_3 {
    public static void main(String[] args) {
      TestStatic ts1 = new TestStatic();
      TestStatic ts2 = new TestStatic();
      ts1.name = "Ken";
      ts2.name = "Vivin";
      System.out.println(ts1.name);
      System.out.println(ts2.name);
      
//      ts1.id = "A0015";
//      ts2.id = "B7153";
        TestStatic.id = "A0015";
        TestStatic.id = "B7153";
//      System.out.println(ts1.id);
//      System.out.println(ts2.id); 
        System.out.println(TestStatic.id);
       System.out.println(TestStatic.id); 
    }
    
}
