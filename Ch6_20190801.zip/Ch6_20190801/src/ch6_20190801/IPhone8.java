/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class IPhone8 extends CellPhone {
    public void callin(){
         System.out.println("呼叫台積電晶片 callin");
     }
   public void callout(){
       System.out.println("呼叫台積電晶片 callout");
   }
    
}
