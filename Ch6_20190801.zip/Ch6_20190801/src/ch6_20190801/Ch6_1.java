/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch6_20190801;

/**
 *
 * @author howard
 */
public class Ch6_1 {

    public static void main(String[] args) {
       
        Test1 t1 = new Test2();        
        t1.testPublic();
        t1.testProtected();
        t1.testDefault();
        
    }
    
}
