/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_1 {

    public static void main(String[] args) {
        //多維
         int[][] array2x3 = new int[2][3];
         int[][] array2xN = new int[2][];
         array2xN[0] = new int[5];
         array2xN[0][2]  = 15;
         System.out.println(array2xN[0][2]);
//         array2xN[0][5] = 71;
//         System.out.println(array2xN[0][5]);
         
         //array2xN[1][0] = 53;//java.lang.NullPointerException
         
         int[][][] array2xnxm = new int[3][][];
         array2xnxm[0] = new int[2][];
         array2xnxm[0][1] = new int[5];
         
         array2xnxm[1]= new int[2][1];
         //array2xnxm[1][0][1]= 71;
         
         //array2xnxm[2][0][1] = 32;
         array2xnxm[0][0][1] = 75;
    }
    
}
