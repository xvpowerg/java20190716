/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_4 {
    //vargs 
      static int sum(int ... values){
          int sum = 0;
          for (int v: values){
              sum += v;
          }
          return sum;
      }
    public static void main(String[] args) {
       
        int value = sum(2,5,7,1,2); 
        System.out.println(value);
        
    }
    
}
