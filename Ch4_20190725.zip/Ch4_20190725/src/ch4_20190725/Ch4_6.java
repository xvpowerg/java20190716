/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        String v1 = "72";
//        String v2 = "51";
//        //字串轉整數
//        int number1 = Integer.parseInt(v1);
//        int number2 = Integer.parseInt(v2);
//        System.out.println(number1 + number2);
            //二進位
//            String v1 =Integer.toBinaryString(193);
//            //八進位
//             String v2 = Integer.toOctalString(193);
//            //１6進位
//            String v3 = Integer.toHexString(193);
//            System.out.println(v1);
//            System.out.println(v2);
//            System.out.println(v3);
    //parseBoolean傳入參數只要不是true一律回傳false
            boolean b1 = Boolean.parseBoolean("true");
            System.out.println(b1);
            boolean b2 = Boolean.parseBoolean("TrUe");
            System.out.println(b2);
            boolean b3 = Boolean.parseBoolean("xxxx");
            System.out.println(b3);
    }
    
}
