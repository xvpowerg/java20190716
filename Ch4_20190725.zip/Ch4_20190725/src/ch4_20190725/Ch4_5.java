/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_5 {

    public static void main(String[] args) {
       //Auto Boxing
       //unAuto Boxing
        
       /*
       byte Byte
       short Short
       int Integer
       long Long
       
       float Float       
       double Double
       
       char  Character
       
       boolean Boolean
       */
       //手動封箱
       Integer intBox = Integer.valueOf(51);
       //解封箱
       int value = intBox.intValue();
       System.out.println(value);
       
       //自動封箱
       Integer intBox2 = 23;
       //自動解封箱
       int value2 = intBox2;       
       System.out.println(value2);
       
       //java.lang.NullPointerException
//       Integer intBox3 = null;
//       int value3 = intBox3;  
//       System.out.println(value3);

  //valueOf有暫存機制~~-128~127 數字作暫存
            Integer intBox4 = 5;
            Integer intBox5 = 5;
            System.out.println(intBox4 == intBox5);
            
            Integer intBox6 = 512;
            Integer intBox7 = 512;
            System.out.println(intBox6 == intBox7);
        
    }
    
}
