/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_2 {
    //方法必要條件
    //1 回傳值 2 方法名稱 3傳入參數 4方法本體
    
    //static 的只能直接呼叫 static的內容
     static void test1(){
         System.out.println("test1!");
     }
     static int test2(int a,int b){
         int ans = a +b;
         //return 有兩個含意
         //1　回傳方法的數值2 離開方法         
         return ans;
     }
    
     static void swapInt(int a,int b){
         int tmp= a;
        a = b;
        b = tmp;
     }
     static void swapArray(int[] array){              
        int tmp = array[0];
        array[0] =  array[1] ;
        array[1] = tmp;
     }
     
     
    public static void main(String[] args) {
//        test1();
//        int sum = test2(5,6);
//        System.out.println(sum);
        int a=25;
        int b=71;
        //所有基本型態都是　Call By Value
//        swapInt(a,b);
//        System.out.println(a+":"+b);

        //所有非基本型態都是 call by Reference
        int[] array = new int[2];
        array[0] = 32;
        array[1] = 85;
        swapArray(array);
        System.out.println(  array[0] +":"+array[1]);
        
    }
    
}
