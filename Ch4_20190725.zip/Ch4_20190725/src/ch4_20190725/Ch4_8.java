/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_8 {
/*
  多載讀取規則
    1 相同類
    2 相同類可相容的
    3 其他類型可相容的
    4 封箱類型    
    */
    
       static void test3(float v1){
        System.out.println("float test3");
    }
    
    
        static void test3(Integer v1){
        System.out.println("Integer test3");
    }
    
    
    static void test1(int v1){
        System.out.println("int v1");
    }
    static void test1(float f1){
        System.out.println("float f1");
    }
    
    static void test2(byte v1){
        System.out.println("byte test2");
    }
    static void test2(float f1){
        System.out.println("float test2");
    }
    
    
    
    static void test4(int v1,float f2){
        System.out.println("int float test4");
    }
  static void test4(int v1,Integer i2){
        System.out.println("int Integer test4");
    }

  
      static void test5(Integer v1,float f2){
        System.out.println("Integer float test5");
    }
         static void test5(int v1,Integer i2){
        System.out.println("int Integer test4");
    }
    
    public static void main(String[] args) {
        //test1(20);
        //20 預設為int 所以byte過小不相容
        //test2(20);
        //test3(10);
        //test4(1,2);
     // test5(1,3);
    }
    
    
    
}
