/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_7 {

    //多載
    //方法名稱要一樣　傳入的參數與數量不一樣
    static void test1(int value,float f1){
        System.out.println(value+":"+f1);
    }
    static void test1(int value){
        System.out.println(value);
    }
    public static void main(String[] args) {
      test1(10);  
      test1(10,12.5f);
     
     
    }
    
}
