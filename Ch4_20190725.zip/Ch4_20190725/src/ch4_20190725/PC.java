/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class PC {
    String cpu;
    //封裝　Encapsulation
    private int memory;
    private String hdisk;
    String motherBoard;
    //JavaBean
    //POJO
    //存錢
    public void setMemory(int inMemory){
        /*Student
姓名不可空白 長度不小於0大於10
年齡不可小於5大於200*/

        switch(inMemory){
            case 4:
            case 8:
            case 16:    
            case 32:         
            case 64:   
           memory = inMemory;
           break;
            default:
                System.out.println("錯誤的記憶體大小");
                break;
        }
        
    }
    //領錢
    public int getMemory(){
        return memory; 
    }
     //CPU
         //記憶體
         //硬碟
         //主機板
    void print(){
        System.out.println(cpu+":"+hdisk+":"+memory+":"+motherBoard); 
    }
    
    public void setHdisk(String  inDisk){
        if (inDisk != null && !inDisk.isEmpty() ){
             hdisk = inDisk;
        }else{
            System.out.println("錯誤的Disk");
        }
       
    }
    public String getDisk(){
        return hdisk;
    }
    
}
