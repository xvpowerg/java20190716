/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_9 {

    public static void main(String[] args) {
        //類別  說明如何要產生什麼樣的物件
        //物件　透過類別產生的實際產品
        
        //電腦
         //CPU
         //記憶體
         //硬碟
         //主機板
         
        PC p1 = new PC();
        p1.cpu = "i5cpu";
        //不要空白　也不要null
        //p1.hdisk = "SSD1TB";
        p1.setHdisk(null);
        p1.setMemory(16);
        //p1.memory = 16;
        p1.motherBoard = "技嘉";
        
        p1.print();
       
        PC p2 = new PC();
        p2.cpu = "i3CPU";
        p2.setHdisk("2TB");
        //4 8 16 32 64
       // p2.memory = 50;
        p2.setMemory(50);
        p2.motherBoard = "華碩";
        System.out.println(p2.getMemory());
        p2.print();
        
        
        
        
    }
    
}
