/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch4_20190725;

/**
 *
 * @author howard
 */
public class Ch4_3 {

    static void testRecursive(int v){
        System.out.println(v);
        if (v <=3){ 
            testRecursive(v + 1);
           //System.out.println(v);
        }
       System.out.println(v);
    }
   static int  factorial(int n){
         if (n <= 1){
             return 1;
         }
      return  factorial(n-1) * n;
   }
   
   static void swap(int[] array,int index1,int index2){
       int tmp = array[index1];
       array[index1] = array[index2] ;
       array[index2] = tmp;
   }
   
   static int pivot(int[] value,int start,int end){
          int cmp = value[start];
          int pivot = start;
            for (int i = start  ; i < end ;  i++){                
                if (cmp > value[i]){
                    pivot++;
                    swap(value,pivot,i);
                }
            }
           swap(value,pivot,start);
          return pivot;
   }
   
   static void qSort(int[] value,int start,int end){
         if (start < end){
             int pivot = pivot(value,start,end);
             qSort(value,start,pivot -1);
             qSort(value,pivot+1,end);
         }       
   }
    
    public static void main(String[] args) {
        // TODO code application logic here
        //testRecursive(1);
      //  int value = factorial(5);
        //System.out.println(value);
        
        int[] array = {5,6,7,9,2};
        qSort(array,0,array.length);
        for (int v : array){
            System.out.print(v+" ");
        }
    }
    
}
