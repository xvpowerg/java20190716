/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

public class Ch7_4 {

    public static void main(String[] args) {
     Ch7_3.TestStaticIneer2 st2 = new Ch7_3.TestStaticIneer2("Lindy", 32);
     System.out.println(st2);    
     Ch7_3.TestInner1 st3 = new Ch7_3().new TestInner1("Join",15);
      System.out.println(st3);
     //方法類別
      class TestFunClass{
          private float[] price; 
          TestFunClass(float... price){
              this.price = price;
          }
         void foreach(){
             for (float p : price){
                 System.out.print(p+" ");
             }
         }
      }
       TestFunClass tfc = new TestFunClass(1.5f,2.6f,5.7f);
      tfc.foreach();
      
      
    }
    
}
