/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

/**
 *
 * @author howard
 */
public interface MyComparable {
    public abstract int compare(int value);
    public int getNumber();
    public default int max(int cmpValue){
          if (compare(cmpValue) > 0){
              return getNumber();
          }else{
              return cmpValue;
          }
    }
    
}
