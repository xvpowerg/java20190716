/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;
public class Chocobo implements ChocoboAction {
    private  int speed = 0;    
    public void setSpeed(int speed){
        this.speed = speed;
    }    
    public void flying(){        
        if (Fly.checkSpeed(speed)){
             System.out.println("Chocobo flying"); 
        }      
    }
    public void runing(){
        speed+=100;
             System.out.println("Chocobo runing");
    }
    public void jumping(){
          System.out.println("Chocobo jumping");
    }
    public void walking(){
        System.out.println("Chocobo walking");  
    }
   public void attackMagic(){
        System.out.println("普通攻擊 二連擊 火 土");  
   }
}
