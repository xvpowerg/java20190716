/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;
import java.io.IOException;
public class Ch7_1 {

    
    public static  void putUsb(Usb usb,String data){
        String type =  usb.getType();
        System.out.println("type:"+type); 
        boolean canReadData = usb.readData(data);
        if (canReadData){
           System.out.println(usb.writeData()); 
        }        
    }
    
    public static void connectionWifi(Wifi wifi,String passwod,String data)throws IOException{
        boolean isConn = false;
       isConn = wifi.connection(passwod);
       if (isConn){
           wifi.input(data);
           System.out.print(wifi.output());
       }        
    }
    public static void main(String[] args) {
      HDisk hd = new HDisk();
      putUsb(hd,"我的資料....");
      putUsb(hd,"AAAA");    
      putUsb(hd,null);  
      
      CellPhone p1 = new CellPhone();
      putUsb(p1,"通訊錄資料....");
      putUsb(p1,"Line Message");   
      try{
          connectionWifi(p1,"1111","測試Wifi通訊....");  
      }catch(Exception ex){
          System.out.println(ex);
      }
   
      
    }
    
}
