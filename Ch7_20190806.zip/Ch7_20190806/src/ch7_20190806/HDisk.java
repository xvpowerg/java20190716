/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

/**
 *
 * @author howard
 */
public class HDisk implements Usb{
    private String data = null;
    public String getType(){
       return "3.0"; 
    }
    public boolean readData(String data){
       // System.out.println("readData:"+data);
        this.data = data;
        return this.data != null;
    }
    public String writeData(){
        return data;
    }
}
