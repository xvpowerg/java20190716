/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;


public class Product implements MyComparable,TestIF3 {
    private int price;
    private String name;
    public Product(int price,String name){
        this.price = price;
        this.name = name;
    } 
    
    public int compare(int inPrice){
         if (this.price >  inPrice ){
             return 100;
         }else{
             return -100;
         }
    }
    public int getNumber(){
        return this.price;
    }
    
    public String toString(){
        return price+":"+name;
    }
}
