/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

/**
 *
 * @author howard
 */
public class Ch7_5 {
    static class MyDog extends Dog{
        public void bark(){
            System.out.println("喵喵!!");
        }
    }
    
    static class Bird implements Fly{
        public void flying(){
            System.out.println("小鳥飛飛飛!!");
        }
    }
    static void testFly(Fly fly){
        fly.flying();
    }
        
    public static void main(String[] args) {
       Dog dog1 = new Dog();
       dog1.bark();
       MyDog dog2 = new MyDog();
       dog2.bark();
      
      Dog dog3 = new Dog(){
          int count =1;
         public void bark(){
             for (;count<=5;count++){
                   System.out.println("支支!"+count);
             }
          
         }      
      };
      dog3.bark();      
      Bird bird = new Bird();
      testFly(bird);

      Fly airPlanFly = new Fly(){
          public void flying(){         
            System.out.println("飛機飛飛飛!!!");
          }      
      };
      airPlanFly.flying();
      int i = 1;
      //lambda語法
//      Fly ironMan = ()->{   
//            System.out.println("鋼鐵人飛飛飛!!");
//      }; 
//      ironMan.flying();
      MyList lsit = (v)->{System.out.println(v);};
      lsit.test1(20);
    }
    
}
