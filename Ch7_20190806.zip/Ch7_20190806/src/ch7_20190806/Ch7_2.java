/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

/**
 *
 * @author howard
 */
public class Ch7_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Chocobo ch1 = new Chocobo();
//        ch1.flying();
//        ch1.runing();
//        ch1.flying();
//        ch1.runing();
//        ch1.runing();
//        ch1.runing();
//        ch1.flying();

        Product p1 = new Product(50,"Pen");
        int max =   p1.max(70);
        System.out.println(max);
        p1.print();
         
    }
    
}
