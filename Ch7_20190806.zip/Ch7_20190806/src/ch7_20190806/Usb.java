/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

public interface Usb {
    //預設情況下 public abstract  void  方法名稱();
    String getType();
    boolean readData(String data);
    String writeData();
    
}
