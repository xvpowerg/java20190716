/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

@FunctionalInterface
public interface Fly {
   int MAX_SPEED = 300;
    void flying();   
  static boolean checkSpeed(int speed){
      if (speed > MAX_SPEED){
          throw new IllegalArgumentException("錯誤的Speed");
      }
      return true;
  }   
    
}
