/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;
public class Ch7_3 {
     //非靜態內部類   
     class TestInner1{
         private String name;
         private int id;
         TestInner1(String name,int id){
             this.name = name;
             this.id = id;
         }
         public String getName(){
             return name;
         }
         public int getId(){
               return id;
         }
         
         public String toString(){
             return this.getName()+":"+this.getId();
         }
     }   
    
     static class TestStaticIneer2{
         private String name;
         private int id;
         public TestStaticIneer2(String name,int id){
             this.name = name;
             this.id = id;
         }
         public String toString(){
             return name+":"+id;
         }
         
     }
     
     
    public void test1(){
        TestInner1 t1 = new TestInner1("Ken",10);   
    }
    public static void main(String[] args) {
        Ch7_3 ch3 = new Ch7_3();
        Ch7_3.TestInner1 t1 = ch3.new TestInner1("Ken",10);
        System.out.println(t1);
       
        TestStaticIneer2 ts = new TestStaticIneer2("Vivin",25);
        System.out.println(ts);
        
    }
    
}
