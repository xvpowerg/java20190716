/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch7_20190806;

import java.io.IOException;

/**
 *
 * @author howard
 */
public class CellPhone implements Usb,Wifi {
    private boolean isConnetion = false;
    private String data;
    private String wifiData;
    public String getType(){
        return "3.1";
    }
   public  boolean readData(String data){
        this.data = data;
        return this.data != null;
    }
   public String writeData(){
        return this.data;
    }
   
   public boolean connection(String password){
       
      isConnetion =  password.equals("qwer");
      if (isConnetion == false){
          throw new IllegalArgumentException("錯誤的密碼!");
      }
       return isConnetion;
   }
   public void input(String data)throws IOException{
       if (isConnetion == false){
           throw new IOException("Wifi斷線中");
       }
       wifiData = data;       
   }
   
   public String output()throws IOException{
          if (isConnetion == false){
           throw new IOException("Wifi斷線中");
       }
       return wifiData;
   }


   
}
