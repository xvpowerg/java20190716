/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;

/**
 *
 * @author shihhaochiu
 */
public class Ch14_2 {
    
    private Object lock;
    int x = 0;
//    public synchronized void test1(){
//        for (int i =1; i<=5 ;i++){
//            System.out.println(++x);
//        }
//    }
//       public  void test1(){
//          System.out.println("V1....:"+Thread.currentThread().getName());
//           synchronized(this){
//                for (int i =1; i<=5 ;i++){
//                    System.out.println(++x+":"+Thread.currentThread().getName());
//                }
//           }
//         System.out.println("V2....:"+Thread.currentThread().getName());
//    }
    
        public void test1(){
            synchronized(lock){
                 for (int i =1;i<=5;i++){
                    System.out.println(++x);
                }
            }
           
        }
    
    public static void main(String[] args) {
        
//        Object lock = new Object();
//        Ch14_2 ch142 = new Ch14_2();
//      
//        Thread t1 = new Thread(()->ch142.test1());
//        Thread t2 = new Thread(()->ch142.test1());
//        t1.start();
//        t2.start();
        
        
        Object lock = new Object();
        Ch14_2 ch142 = new Ch14_2();
        ch142.lock = lock;
        Thread t1 = new Thread(()->ch142.test1());
        Thread t2 = new Thread(()->ch142.test1());
        t1.start();
        t2.start();
        
        
        
//         Object lock = new Object();
//        Ch14_2 ch142 = new Ch14_2();
//        Ch14_2 ch143 = new Ch14_2();
//        ch142.lock = lock;
//        ch143.lock = lock;
//        Thread t1 = new Thread(()->ch142.test1());
//        Thread t2 = new Thread(()->ch143.test1());
//        t1.start();
//        t2.start();
        
    }
    
}
