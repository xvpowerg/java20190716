/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
public class Ch14_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ExecutorService es =   Executors.newFixedThreadPool(3);
       Runnable myRun = ()->{
           System.out.println("Thread Name:"+Thread.currentThread().getName());
           int sleep = ThreadLocalRandom.current().nextInt(5)+1;
           try{
               TimeUnit.SECONDS.sleep(sleep);
           }catch(InterruptedException ex){
               System.out.println(ex);
           }
           
       };
        es.execute(myRun);
       es.execute(myRun);
        es.execute(myRun);
           es.execute(myRun);
       es.execute(myRun);
        es.execute(myRun);
        
        //es.shutdown();
        es.shutdownNow();
    }
    
}
