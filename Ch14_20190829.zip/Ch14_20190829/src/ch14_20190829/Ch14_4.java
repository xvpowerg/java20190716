/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
public class Ch14_4 {

    
    public static void main(String[] args) {
        
        Runnable myRun = ()->{
            int time = ThreadLocalRandom.current().nextInt(5)+1;
            System.out.println("開始計算秒數："+time+":"+Thread.currentThread().getName());
            
            try{
                TimeUnit.SECONDS.sleep(time); 
            }catch(InterruptedException ex){
                System.out.println(ex);
            }
        System.out.println("計算完成："+Thread.currentThread().getName());
        };
        
       ExecutorService es = Executors.newCachedThreadPool();
        es.execute(myRun);
        es.execute(myRun);
        es.execute(myRun);
        es.execute(myRun);
        es.execute(myRun);
        es.shutdown();
        
    }
    
}
