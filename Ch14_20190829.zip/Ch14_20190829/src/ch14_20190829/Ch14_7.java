/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
public class Ch14_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String url="jdbc:derby://localhost:1527/MyDB";
       String user ="qwer";
       String pass ="12345";
//       try{
//         Connection con  =DriverManager.getConnection(url, user, pass);
//        Statement stem =  con.createStatement();
//        stem.executeUpdate("INSERT INTO USERINFO (name,id,integral) VALUES('Willan',200,56.1)");
//       }catch(SQLException ex){
//           System.out.println(ex);
//           
//       }
//        

//        Connection con = null;
//        Statement stem = null;    
//        try{
//            con = DriverManager.getConnection(url,user,pass);
//            stem = con.createStatement();
//            stem.executeUpdate("UPDATE USERINFO SET NAME = 'Tank' WHERE ID= 104");
//        }catch(SQLException ex){
//            System.out.println(ex);
//        }finally{
//            try{
//                 stem.close();
//                 con.close();
//            }catch(SQLException ex){
//                
//            }
//           
//        }

//        try(Connection con = DriverManager.getConnection(url,user,pass);
//           Statement stem = con.createStatement()){
//           int count =  stem.executeUpdate("DELETE FROM USERINFO WHERE ID=103");
//           if (count > 0){
//               System.out.println("刪除成功");
//           }else{
//                System.out.println("刪除失敗");
//           }
//        }catch(SQLException ex){
//            System.out.println(ex);
//        }
        

    try(Connection con = DriverManager.getConnection(url,user,pass);
            Statement stm = con.createStatement();){
           ResultSet resSet =   stm.executeQuery("SELECT * FROM USERINFO");
           while(resSet.next()){
              int id =  resSet.getInt(1);
              String name = resSet.getString(2);
              float integral =  resSet.getFloat("integral");
              System.out.println(id+":"+name+":"+integral);
           }
    }catch(SQLException ex){

    }
        
    }
    
}
