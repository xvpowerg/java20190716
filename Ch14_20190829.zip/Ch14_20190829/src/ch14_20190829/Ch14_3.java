/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;

/**
 *
 * @author shihhaochiu
 */
public class Ch14_3 {
    
   static class TestLock{
       String name = "";
       TestLock(){
           
       }
       TestLock(String name){
           this.name = name;
       }
       public synchronized void test1(TestLock lock){
           System.out.println("Test1:"+name);
           lock.test2();
       }
       public synchronized void test2(){
          System.out.println("Test2:"+name);
       }
   }
    
    public static void main(String[] args) {
      //死結
      // 1 一個以上的執行緒
      // 2 一定有資源分享等待的狀態
      
      TestLock testLock1 = new TestLock("T1");
      TestLock testLock2 = new TestLock("T2");
      
      Thread t1 = new Thread(()->{testLock1.test1(testLock2);});
      Thread t2 = new Thread(()->{testLock2.test1(testLock1);});
      t1.start();
      t2.start();
    }
    
}
