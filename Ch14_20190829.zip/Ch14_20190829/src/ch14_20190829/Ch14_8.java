/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
/**
 *
 * @author shihhaochiu
 */
public class Ch14_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Properties p1 = new Properties();
        try{
            FileInputStream fin = new FileInputStream("/Users/shihhaochiu/javadir/db.properties");
             p1.load(fin); 
        }catch(IOException ex){
            System.out.println(ex);
        }
       
      String url=p1.getProperty("url");
       String user =p1.getProperty("user");
       String pass =p1.getProperty("password");
       
       try(Connection con = DriverManager.getConnection(url,user,pass);
            Statement stm = con.createStatement();){
           ResultSet resSet =   stm.executeQuery("SELECT * FROM USERINFO");
           while(resSet.next()){
              int id =  resSet.getInt(1);
              String name = resSet.getString(2);
              float integral =  resSet.getFloat("integral");
              System.out.println(id+":"+name+":"+integral);
           }
    }catch(SQLException ex){

    }
    }
    
}
