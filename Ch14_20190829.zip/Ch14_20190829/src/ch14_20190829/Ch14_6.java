/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;

import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Stream;

public class Ch14_6 {

    static Stream<Integer> getLooton(){
        Set<Integer>set = new TreeSet();
        System.out.println("開始產生樂透號ㄡ.....");
        try{
            TimeUnit.SECONDS.sleep(3);
        }catch(InterruptedException ex){
            
        }
        
        System.out.println("開始產生樂透號完畢.....");
        //一組數字內有 六筆不同的號碼 由1~58中間的任一個數
        
        while(set.size() < 6){
            set.add(ThreadLocalRandom.current().nextInt(58)+1);
        }
        
       return set.stream();
    }
    public static void main(String[] args) {
      
        ExecutorService es = Executors.newFixedThreadPool(3); 
        ExecutorService futEs = Executors.newFixedThreadPool(3);

        Future<Stream<Integer>> fuStr=  es.submit(Ch14_6::getLooton);
        System.out.println("取得資料中!!!");
       
        futEs.execute(()->{
           try{
            Stream<Integer> str = fuStr.get();  
            str.forEach(System.out::println);
          
            }catch(InterruptedException|ExecutionException ex){
                System.out.println(ex);
            }
        });
        
     
           System.out.println("完成!!!");  
           futEs.shutdown();
           es.shutdown();
    }
    
}
