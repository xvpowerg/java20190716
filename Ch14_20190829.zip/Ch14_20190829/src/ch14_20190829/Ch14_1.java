/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch14_20190829;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.PathMatcher;
import java.util.stream.Stream;
public class Ch14_1 {

    public static void main(String[] args) {
       
        
        Path path = Paths.get("/Users/shihhaochiu/javadir/");
//        try{
//        Stream<Path> stram = Files.walk(path);
//        stram.filter(path2->path2.endsWith("abc.txt")).forEach(System.out::println);
//        }catch(IOException ex){
//            System.out.println(ex);
//        }      
        


//        try{
//            Stream<Path> stram = Files.walk(path,2);
//            stram.forEach(System.out::println);
//        }catch(IOException ex){
//            System.out.println(ex);
//        }  

//PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:**.txt");
//       
//           try{
//            Stream<Path> stram = Files.walk(path);
//            stram.filter( p1 ->matcher.matches(p1)).forEach(System.out::println);
//        }catch(IOException ex){
//            System.out.println(ex);
//        } 
    
    
    }
    
}
