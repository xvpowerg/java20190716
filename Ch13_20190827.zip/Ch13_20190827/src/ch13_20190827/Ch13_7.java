/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch13_7 {

   
    public static void main(String[] args) {
        String value = "Howard Ken Vlvin";
        File f1 = new File("/Users/shihhaochiu/javadir/myvalue.dao");
        try(FileOutputStream fout = new FileOutputStream(f1);
            ObjectOutputStream objOut = new ObjectOutputStream(fout);){
       
            objOut.writeObject(value);
             
        }catch(IOException ex){
            System.out.println(ex);
        }
        
        
        
    }
    
}
