/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch13_11 {


    public static void main(String[] args) {
          File f1 = new File("/Users/shihhaochiu/javadir/student.dao");
       Student st1 = new Student("Ken",25,"A0001",85);
       st1.setMacAdr("198.71.6.5");
       st1.setBook(new Book("java","ISBN12553"));
       try(FileOutputStream four = new FileOutputStream(f1);
          ObjectOutputStream objOut = new ObjectOutputStream(four);)
       {
           
           objOut.writeObject(st1);
       }catch(IOException ex){
           System.out.println(ex);
       }
    }
    
}
