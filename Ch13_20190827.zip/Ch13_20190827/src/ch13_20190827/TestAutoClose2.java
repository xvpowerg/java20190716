/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.sql.SQLException;
/**
 *
 * @author shihhaochiu
 */
public class TestAutoClose2  implements  AutoCloseable{
    private String name;
    private boolean thwsException;
    public TestAutoClose2(String name,boolean thwsException){
        this.name = name;
       this.thwsException= thwsException;
               }
    public void printInfo(){
        System.out.println("Body:"+name);
    }
    
    public void close()throws SQLException {
        System.out.println("Close:"+ name+ "...........:");
     if (thwsException) throw new SQLException("TestAutoClose2 Exception!"+name);
    }
}
