/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
/**
 *
 * @author shihhaochiu
 */
public class Ch13_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        File f1 = new File("/Users/shihhaochiu/javadir/student.dao");
        
        try(FileInputStream fin = new FileInputStream(f1);
            ObjectInputStream objIn = new  ObjectInputStream(fin);   ){
           Student st = (Student) objIn.readObject();
           System.out.println(st);
        }catch(Exception ex){
            System.out.println(ex);
        }
        
        
        
    }
    
}
