/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.IOException;
import java.io.Serializable;
/**
 *
 * @author shihhaochiu
 */
public class Student extends Person implements Serializable {
    private static final long serialVersionUID = 0xF11229L;
    private String classId;
    private int score = 0;
    private transient Book book;
    private String macAdr;
    public Student(String name,int age,String classId,int score){
        super(name,age);
        this.classId = classId;
        this.score = score;
    }
    public void setMacAdr(String macAdr){
        this.macAdr = macAdr;
    }
    
   public void setBook(Book book){
        this.book = book;
    }
    
    public String getClassId(){
        return classId;
    }
    public int getScore(){
        return score;
    }
    
    public String toString(){
        
        return super.toString()+":"+classId+":"+score+"Book:"+book+"MacAdr:"+macAdr;
    }
    
    private void writeObject(java.io.ObjectOutputStream out)throws IOException{
        System.out.println("writeObject......");
        out.defaultWriteObject();
    }
    
    private void readObject(java.io.ObjectInputStream in) throws IOException,ClassNotFoundException{
        System.out.println("readObject.....");
        in.defaultReadObject();
        this.macAdr = "127.0.0.1";
    }
    
}
