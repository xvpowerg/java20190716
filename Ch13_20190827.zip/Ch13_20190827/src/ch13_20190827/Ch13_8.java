/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
public class Ch13_8 {

   
    public static void main(String[] args) {
     
        File file = new File ("/Users/shihhaochiu/javadir/myvalue.dao");
        
        try(FileInputStream fins = new FileInputStream(file);
            ObjectInputStream objInp = new  ObjectInputStream(fins);   ){
            
            String value = (String)objInp.readObject();
            System.out.println(value);
            
        }catch(IOException | ClassNotFoundException  ex){
            System.out.println(ex);
        }
        
        
        
        
    }
    
}
