/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;

import java.io.Serializable;

/**
 *
 * @author shihhaochiu
 */
public class Person implements Serializable {
    private String name;
    private int age;
    
    public Person(){
        
    }
    public  Person(String name,int age){
        this.name = name;
        this.age = age;
    }
    
    public String getName(){
        return this.name;
    }
    
    public int getAge(){
        return this.age;
    }
    
    public String toString(){
        return this.getName()+":"+this.getAge();
    }
}
