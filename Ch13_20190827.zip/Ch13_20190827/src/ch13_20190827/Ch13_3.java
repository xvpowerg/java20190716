/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
//        try(TestAutoClose1  t1 = new TestAutoClose1("Test1");
//           TestAutoClose1  t2 = new TestAutoClose1("Test2");){
//           
//            t1.printInfo();
//            t2.printInfo();
//        }

//try(TestAutoClose1  t1 = new TestAutoClose1("Test1");
//           TestAutoClose1  t2 = new TestAutoClose1("Test2");){
//           
//            t1.printInfo();
//            t2.printInfo();
//        }finally{
//     System.out.println("finally.....");
//     }


try(TestAutoClose1  t1 = new TestAutoClose1("Test1");
           TestAutoClose1  t2 = new TestAutoClose1("Test2");){
            t1.printInfo();
            t2.printInfo();
             throw new Exception("Test1~2 Exception");
        }catch(Exception ex){
            System.out.println(ex);
        }finally{
     System.out.println("finally.....");
     }

    }
    
}
