/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
public class Ch13_10 {
    
    
    private static  int getNumberHead(int v1){
         int d = 10;
            while((v1 / d) > 9  ){
                d*=10;
            }
         return  v1 / d;
    } 
    
    public static void main(String[] args) {
        
       
           
        
       File file = new File("/Users/shihhaochiu/javadir/myMap.dao");  
        try(FileInputStream fin = new FileInputStream(file);
            ObjectInputStream objin = new   ObjectInputStream(fin);  ){
        Map<String,Integer>  map =  (Map)  objin.readObject();
        //System.out.println(map.get("BoBo"));
//            if ( map.containsKey("BoBo") == false){
//                System.out.println("不存在");
//            }else{
//                System.out.println(map.get("BoBo"));
//            }

//  Map<Integer,List<Entry<String,Integer>>> map2 =  map.entrySet().stream().collect(
//          Collectors.groupingBy((entry)->getNumberHead(entry.getValue())));  
//  System.out.println(map2);
//  
  
   Map<Integer,List<String>> map3 =  map.entrySet().stream().collect(
          Collectors.groupingBy((entry)->getNumberHead(entry.getValue()),
                  Collectors.mapping((entry)->entry.getKey(), Collectors.toList())));  
  System.out.println(map3);
 
 // Map<Integer,List<String>> map3 = new HashMap();
  
  
        }catch(IOException | ClassNotFoundException ex){
            System.out.println(ex);
        }
        
        
        
    }
    
}
