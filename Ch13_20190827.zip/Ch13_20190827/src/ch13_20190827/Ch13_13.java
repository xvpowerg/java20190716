/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;

public class Ch13_13 {
    public static void main(String[] args) {
      Path path =   Paths.get("/Users/shihhaochiu/javadir/student.dao");
      System.out.println(path.getName(2));
       System.out.println(path.getRoot());
       System.out.println(path.getParent());
       System.out.println(path.getFileName());
     Path path1 =   Paths.get("/Users/shihhaochiu/javadir/student.dao");
  
      Path subPath = path1.subpath(1, 3);
      System.out.println(subPath);
      
      Path path2 =   Paths.get("/Users/shihhaochiu/javadir/");
       Path path3 =   Paths.get("MyFule.txt");
     Path path4 =   path2.resolve(path3);
     System.out.println(path4);
     
     //因為path6為完整路徑所以變成取代
      Path path5 =   Paths.get("/Users/shihhaochiu/javadir/");
      Path path6 =   Paths.get("/Users/MyFule.txt");
     Path path7 =   path5.resolve(path6);
     System.out.println(path7);
     
    
      
    }
    
}
