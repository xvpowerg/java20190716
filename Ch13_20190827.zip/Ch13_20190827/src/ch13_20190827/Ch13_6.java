/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File file = new File("/Users/shihhaochiu/javadir/myWrite.txt");
       String value = "Hello! Writer";
       try(FileWriter fw = new FileWriter(file);){
           fw.write(value);
                 
       }catch(IOException ex){
           System.out.println(ex);
       }
       
    }
    
}
