/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_2 {
    
    
    
    public static void main(String[] args) {
        
        try(Wifi wifi = new Wifi();){
              wifi.connection("qwer", "12345");
        } 
        
      
        
        
    }
    
}
