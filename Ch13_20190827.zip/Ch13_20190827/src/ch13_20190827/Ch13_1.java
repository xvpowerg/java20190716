/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
/**
 *
 * @author shihhaochiu
 */
public class Ch13_1 {

    
    public static void main(String[] args) {
       File src = new File("/Users/shihhaochiu/javadir/eclipse-inst-mac64.tar.gz");
       File target = new File("/Users/shihhaochiu/javadir/eclipse-copy.tar.gz"); 
     
      try(FileInputStream fin  = new FileInputStream(src);
          FileOutputStream fout = new FileOutputStream(target);){
          byte[] buffer =new byte[1024 ];
          
          int index =-1;
          while ( (index = fin.read(buffer) ) != -1  ){
              fout.write(buffer, 0, index);
          }
      }catch(IOException ex){
          System.out.println(ex);
      }
       
       
      
//傳統      
//       try{
//          fin = new FileInputStream(src);
//          fout = new FileOutputStream(target);
//          byte[] buffer =new byte[1024 ];
//          
//          int index =-1;
//          while ( (index = fin.read(buffer) ) != -1  ){
//              fout.write(buffer, 0, index);
//          }
//          
//          
//      }catch(IOException ex){
//          System.out.println(ex);
//      }finally{
//          try{
//              fout.close();
//              fin.close();
//          }catch(IOException ex){
//               System.out.println(ex);
//          }
// 
//      }
       
        
    }
    
}
