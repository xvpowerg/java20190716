/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.util.HashMap;
import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class Ch13_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HashMap<String,Integer> map = new HashMap<>();
        map.put("Vivin",571);
        map.put("Lindy",95);
        map.put("Ken",82);
        map.put("Join",51);
        
        File file = new File("/Users/shihhaochiu/javadir/myMap.dao");
        try(FileOutputStream fout = new FileOutputStream(file);
          ObjectOutputStream objStr= new  ObjectOutputStream(fout);     ){
            System.out.println("序列化中....");
            objStr.writeObject(map);
        }catch(IOException ex){
        System.out.println("IOException....:"+ex);
        }
        
    }
    
}
