/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;

/**
 *
 * @author shihhaochiu
 */
public class Wifi implements AutoCloseable {
   private String name = "qwer";
   private String password = "12345"; 
   
   public boolean connection(String name,String password){
       if (this.name.equals(name) && this.password.equals(password)){
           System.out.println("Connected Success!!");
           return true;
       }
           System.out.println("Connected Fail!!");
          return false;
   }
   
   public void close(){
        System.out.println("Close Connected ");
   }
   
   
   
    
}
