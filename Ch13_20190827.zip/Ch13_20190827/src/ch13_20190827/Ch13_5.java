/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;

public class Ch13_5 {

    public static void main(String[] args) {
        File file = new File("/Users/shihhaochiu/javadir/myFile.txt");
//        try( FileReader fer = new FileReader(file);){
//            int data = -1;
//            while ( (data = fer.read()) != -1 ){
//                  System.out.print( (char)data);
//                
//            }
//        }catch(IOException ex){
//            System.out.println(ex);
//        }

        try(FileReader fer = new FileReader(file);
          BufferedReader bf = new BufferedReader(fer);){
            String text=null;    
            while ( (text = bf.readLine()) != null){
                System.out.println(text);              
            }
            
        }catch(IOException ex){
                System.out.println(ex);
        }


       
    }
    
}
