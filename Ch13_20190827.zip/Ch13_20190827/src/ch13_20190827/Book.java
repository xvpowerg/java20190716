/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;
import java.io.Serializable;
/**
 *
 * @author shihhaochiu
 */
public class Book {
    private String isbn;
    private String name;
    public Book(String isbn,String name){
        this.isbn = isbn;
        this.name = name;        
    }
    
    public String toString(){
        return this.name+":"+this.isbn;
    }
}
