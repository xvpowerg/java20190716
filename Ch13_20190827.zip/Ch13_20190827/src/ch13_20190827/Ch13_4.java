/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch13_20190827;

import java.sql.SQLException;

/**
 *
 * @author shihhaochiu
 */
public class Ch13_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        
//       try(TestAutoClose2 t2 = new TestAutoClose2("Test1",true);
//           TestAutoClose2 t3 = new TestAutoClose2("Test2",false);  ){
//           
//           System.out.println("Body....");
//           
//       }catch(SQLException ex){
//           System.out.println(ex);
//       }
        
//
//       try(TestAutoClose2 t2 = new TestAutoClose2("Test1",true);
//           TestAutoClose2 t3 = new TestAutoClose2("Test2",true);  ){
//           
//           System.out.println("Body....");
//           
//       }catch(SQLException ex){
//           System.out.println(ex);
//          Throwable[] ths =  ex.getSuppressed();
//          for (Throwable th : ths){
//            //  System.out.println(th);
//              
//          }
//       }
//
       try(TestAutoClose2 t2 = new TestAutoClose2("Test1",true);
           TestAutoClose2 t3 = new TestAutoClose2("Test2",true); ){
           
           System.out.println("Body....");
           throw new SQLException("Body Exception....");
       }catch(SQLException ex){
           System.out.println(ex);
           Throwable[] ths =ex.getSuppressed();
             for (Throwable th : ths){
              System.out.println(th);
              
          }
       }
//        
    }
    
}
