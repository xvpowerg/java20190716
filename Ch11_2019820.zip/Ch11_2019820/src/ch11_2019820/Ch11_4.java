/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.Random;
import java.util.stream.Stream;
import java.util.stream.IntStream;
import java.util.stream.DoubleStream;
import java.util.stream.LongStream;
public class Ch11_4 {
   private static Random random = new Random();
    static String getString(){
        StringBuffer sb = new StringBuffer();      
        for (int i= 1;i<=5;i++){            
            char tmpChar =(char)(random.nextInt(26) + 'A');
            sb.append(tmpChar);          
        } 
        return sb.toString();
    }
    
    public static void main(String[] args) {
//          Stream<String> st = Stream.of("Ken","Vivin","Join","Lindy");
//          st.forEach(System.out::println);
          
//         Stream<String> st2 = Stream.generate(Ch11_4::getString);
//         st2.limit(10).forEach(System.out::println);
          
//        String tmpValue = "產品價格:";
//       Stream<String> priceStr =  Stream.iterate(tmpValue, (title)->{             
//            title+=""+random.nextInt(10000)+"," ;
//         return title;
//         });
//       priceStr.limit(5).forEach(System.out::println);

        //IntStream.iterate(1, (v)->v+1).limit(6).forEach(System.out::println);
        IntStream.range(5, 10).forEach(System.out::println);
    }
    
}
