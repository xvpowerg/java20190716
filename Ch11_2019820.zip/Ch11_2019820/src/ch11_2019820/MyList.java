/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.ArrayList;

/**
 *
 * @author howard
 */
public class MyList<T> {
    private ArrayList<T> baseLsit = new ArrayList<>();
    
    public void add(T value){
        baseLsit.add(value);
    }
    public T get(int index){
        return baseLsit.get(index);
    }
    
    
}
