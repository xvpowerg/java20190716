/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.stream.Stream;
public class Ch11_6 {

    public static void main(String[] args) {
     Stream<String>  strName = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
     //allMatch 所有都成立回傳true
//     boolean b1 = strName.allMatch((n)->n.length() > 2);
//     System.out.println(b1);
//只要一個成立就回傳true
//      boolean b2 = strName.anyMatch((n->n.indexOf("o") >=0 ));
//           System.out.println(b2);
//沒有任何一個成立就回傳true     
//        boolean b3 =  strName.noneMatch((n)->n.endsWith("y"));
//        System.out.println(b3);
//        boolean b4 =  strName.noneMatch((n)->n.endsWith("x"));
//        System.out.println(b4);
 //短路現象
 //allMatch 短路 只要碰到條件為false時 回傳false
  boolean b5 = strName.peek(System.out::println).allMatch((n)->n.length() > 3);
  //anyMatch 短路 只要碰到條件為true時 回傳true
  //boolean b6 = strName.peek(System.out::println).anyMatch((n)->n.endsWith("y"));
   //noneMatch 短路 只要碰到條件為true時 回傳false
  //boolean b7 =  strName.peek(System.out::println).noneMatch((n)->n.endsWith("s"));
  
    }
    
}
