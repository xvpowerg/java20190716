/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.Optional;
import java.util.OptionalInt;
/**
 *
 * @author howard
 */
public class Student {
    private String name;
    private int age;
    public void setName(String name){
        this.name = name;
    }
    public Optional<String> getName(){
        
        return Optional.ofNullable(name);
    }
    
   public void setAge(OptionalInt age){
       if (age.isPresent()){
           this.age = age.getAsInt();
       }
        
    }
    public int getAge(){
        return age;
    }
    
}
