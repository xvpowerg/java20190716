/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;
/**
 *
 * @author howard
 */
public class Item<V, T extends List<V>> {
    T baseList;
    public void setList(T list,V value){
        if (baseList == null){
            baseList =  list;
        }
       baseList.add(value);
    }
    
    public void foreach(Consumer<V> cons){
        baseList.forEach(cons);
    }
    
    public static <R>  R getSupplier(Supplier<R> sup){                
       return sup.get();
    }
    
}
