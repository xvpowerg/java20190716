/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;

import java.util.ArrayList;
import java.util.function.Supplier;
public class Ch11_3 {

    
    public static void main(String[] args) {
       
        Item<Integer,ArrayList<Integer>> items = new Item<>();
        ArrayList list = new ArrayList();
        items.setList(list, 10);
        items.setList(null, 20);
        items.setList(null, 30);
        items.foreach(System.out::println);
     
        String name = items.getSupplier(()->"Ken");
        System.out.println(name);        
        
        int value = items.<Integer>getSupplier(()->{ return 100;});
        System.out.println(value);
    }
    
}
