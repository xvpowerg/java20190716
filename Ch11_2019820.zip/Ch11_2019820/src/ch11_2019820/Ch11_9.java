/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.Optional;
public class Ch11_9 {


    public static void main(String[] args) {
        String value1 = "Hello!!";
      Optional<String> op1 =  Optional.of(value1);
      Optional<String> op2 =  Optional.ofNullable(value1);
      System.out.println(op1);
        System.out.println(op2);
             String value2 =null;
    // Optional<String> op4 =  Optional.ofNullable(value2);
     //System.out.println(op4);
     //of 碰到null會拋例外
     // Optional<String> op3 =  Optional.of(value2);          
    //    System.out.println(op3);   
        
     //Optional<String> op5 =   Optional.empty();
      Optional<String> op5 =   Optional.of("Vivivn");
//     if (op5.isPresent()){
//       System.out.println(op5.get());
//     }

       System.out.println(op5.orElse("空白"));
     
        
    }
    
}
