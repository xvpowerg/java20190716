/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;

import java.util.OptionalInt;

/**
 *
 * @author howard
 */
public class Ch11_8 {

    public static void main(String[] args) {
      
        Student st1 = new Student();
        st1.setAge(OptionalInt.of(10));
        st1.setName("Vivin");
        if (st1.getName().isPresent() && st1.getName().get().length() > 1){
            System.out.println(st1.getName().get());
        }
        
//        if (st1.getName()!=null && st1.getName().length() > 1){
//            System.out.println(st1.getName());
//        }
        
    Student st2 = new Student();
        OptionalInt optionalInt = OptionalInt.empty();
    // st2.setAge(optionalInt);
     st2.setAge(OptionalInt.of(35));
     System.out.println(st2.getAge());
    }
    
}
