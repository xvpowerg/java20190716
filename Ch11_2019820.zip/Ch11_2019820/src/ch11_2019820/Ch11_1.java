/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;

/**
 *
 * @author howard
 */
public class Ch11_1 {
    
    public static void main(String[] args) {
        MyList list = new MyList();
        list.add("Apple");
        list.add("Kiwi");
        list.add("Charry");
        System.out.println(list.get(0));
        System.out.println(list.get(1));
         System.out.println(list.get(2));
         
          MyList<Integer> list2 = new MyList<>();
         list2.add(20);
         list2.add(80);
         list2.add(55);
         System.out.println(list2.get(0));
    }
    
}
