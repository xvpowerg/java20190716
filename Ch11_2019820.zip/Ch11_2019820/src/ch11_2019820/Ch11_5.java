/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.ArrayList;
import java.util.stream.Stream;
public class Ch11_5 {

   
    public static void main(String[] args) {
       
        ArrayList<String> list = new ArrayList();
        list.add("Ken");
        list.add("Howard");
        list.add("Vivin");
       // list.stream().forEach(System.out::println);
        //一個Stream只能使用一次
//        Stream<String>  st1 = list.stream();
//        st1.forEach(System.out::println);
//        st1.forEach(System.out::println);
        //Stream 不會改變來源
        //filter  意思為過濾  過濾 文字長度小於3的
        //filter內的條件回傳false就會被過濾
//        list.stream().filter(st->st.length() > 3).forEach(System.out::println);
//        System.out.println(list.size());
        //Stream 惰性layzy  終端的 terminal
        //如果peek有被執行就是terminal
        list.stream().peek(v->System.out.println(v)).filter(st->st.length() > 3);

          list.stream().peek(v->System.out.println("peek:"+v)).
                  filter(st->st.length() > 3).forEach(System.out::println);
    }
    
}
