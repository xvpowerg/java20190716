/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;
import java.util.ArrayList;
/**
 *
 * @author howard
 */
public class Ch11_2 {

   static void showTest1List(ArrayList<Test1> list ){
       
   }
   static void showTestListSub(ArrayList<? extends Test1> list){
       //不可add
       //list.add(new Test1());
       Test1 t1 =  list.get(1);
   }
   static void showTest2ListParnet(ArrayList<? super Test2> list){
       //只要是Test2或子類都可add
       Test2  t1 = new Test2();
       list.add(t1);
       //get回傳只能是Object
       //Test3 obj =list.get(0);
   }
    public static void main(String[] args) {
     //  Test1 t2 = new Test2();
     //錯誤優~~前後泛型必須一樣 或在右邊的泛型符號加上<>(diamond)
      ArrayList<Test1> list = new ArrayList<>(); 
        
      ArrayList<Test1> list2 = new ArrayList<Test1>(); 
      showTest1List(list2);
      
      ArrayList<Test2> list3 = new ArrayList<Test2>(); 
      showTestListSub(list3);
      
      ArrayList<Test1> list4 = new ArrayList<Test1>();  
      showTest2ListParnet(list4);
    }
    
}
