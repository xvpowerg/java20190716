/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch11_2019820;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Stream;

/**
 *
 * @author howard
 */
public class Ch11_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Stream<String>  strName = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
       long count = strName.filter(n->n.endsWith("n")).count();
       System.out.println(count);

     Stream<String>  strName2 = Stream.of("Vivin","Vivin","Iris","Lindy","Iris","Tom");
         long conut2 = strName2.distinct().count();
         System.out.println(conut2);
         
   Stream<String>  strName3 = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
        Optional<String> opStr1 =  strName3.findAny();
        System.out.println(opStr1.get());
//        Optional<String> opStr2 = strName3.findFirst();   
//        System.out.println(opStr2.get());
 System.out.println("======================");
  Stream<String>  strName4 = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
//strName4.parallel().forEach(System.out::println);
strName4.parallel().forEachOrdered(System.out::println);
  Stream<String>  strName5 = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
 Optional<String>  maxName =  strName5.max(Comparator.comparing(s->s));
 System.out.println(maxName.get());
  System.out.println("======================");
  Stream<String>  strName6 = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
  strName6.unordered().forEach(System.out::println);
  //strName6.unordered().parallel().forEach(System.out::println);
 // strName6.unordered().parallel().sequential().forEach(System.out::println);
  System.out.println("======================");
 Stream<String>  strName7 = Stream.of("Vivin","Ken","Iris","Lindy","Join","Tom");
 strName7.skip(2).forEach(System.out::println);
 //strName7.sorted().forEach(System.out::println);
// strName7.sorted().sorted(Comparator.<String,String>comparing(s->s).reversed());
    }
    
}
