/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_1 {
    public static void main(String[] args){
        //變數命名規則
        //變數名稱開頭可以是英文字母　底線(_)　或錢字號($)
        //變數名稱第二個字開始　可以是英文字母　底線(_)　或錢字號($)與　數字
        //不可使用關鍵字
        int a1 = 10;
        int _a2 = 58;
        int $_3 = 71;
        int a$_2 = 51;
        
        //int 2a = 86; //錯誤        
        //關鍵字
        /*https://docs.oracle.com/javase/tutorial/java/nutsandbolts/_keywords.html*/
        //整數變數其他進位
        //2進位 常用
        //數字開頭為0b為2進位
        int binary = 0b01101;
        System.out.println(binary);
        //8進位
        //數字開頭為0為8進位
        int oct = 017;
        System.out.println(oct);
        //16進位常用 應用範圍　顏色表達　或過濾某些數字
        //數字開頭為0x為16進位
        //A=10 B = 11 C = 12 D = 13 E = 14 F = 15
        int hex = 0x001F;
        System.out.println(hex);
        //底線的使用
        //底線的規則
        //底線的前後必須是數字或底線
        int price1 = 1_000_000_000;
        System.out.println(price1);
        //int price2 = _123__456;//錯誤因為第一個_前面不合規則
        int price3 = 0xFF101_B;
        //int price4 = 0x_FF101_B;//錯誤因為第一個_前面不合規則
        int price5 = 0_12_567;//要注意
       // float price6 = 123._56_789f;//錯誤因為第一個_前面為dot(.)
    }
}
