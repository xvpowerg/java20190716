/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_2 {
    public static void main(String[] args){
            int hp = 500;
            int attack = 10;
            //複合運算            
            hp = hp - attack;            
            System.out.println (hp);
            hp = hp - attack;
            System.out.println (hp);
            hp = hp + 5;
            System.out.println (hp);
            //複合指定運算子
            hp -= attack;
             System.out.println (hp);
            hp -= attack;
            System.out.println (hp);
            hp += 10;
            System.out.println (hp);
            //一元運算子
            int count =0;            
            count++;
            count++;
            System.out.println(count);
            count--;
            System.out.println(count);
    }
}
