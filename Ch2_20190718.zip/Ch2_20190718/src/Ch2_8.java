/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
import java.util.Scanner;
public class Ch2_8 {
    public static void main(String[] args){
        //請輸入半徑
        //計算出此圓的面積
        //pi = 3.1415;
        //area = pi * r * r;
        final float  PI= 3.1415f;
        System.out.println("請輸入半徑");
        Scanner scan  = new Scanner(System.in);
        int r = scan.nextInt();
        float area = PI * r * r;
        System.out.printf("圓面積:%.2f",area);
        
        
        
    }
}
