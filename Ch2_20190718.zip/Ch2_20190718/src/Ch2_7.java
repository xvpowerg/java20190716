/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */

import java.util.Scanner;
public class Ch2_7 {
    public static void main(String[] args){
        String name = "Howard";
        int age = 10;
        float height = 172.6f;
        
        Scanner scan = new Scanner(System.in);
       System.out.print("請入姓名");
       name = scan.next();
        System.out.print("請入年齡");
        age = scan.nextInt();
     System.out.print("請入身高");
      height = scan.nextFloat();
        //姓名　年齡　身高
        System.out.println("姓名:"+name+"年齡:"
                +age+"身高:"+height);
        //%s 表示填入字串
        //%d 表示整數
        //%f 表示浮點數 .2f% 表示小數點取道地2位　且會四捨五入
        //%n 表示要顯示斷行
        System.out.printf("姓名:%s 年齡:%d　身高:%.2f%n",
                name,age,height);
        
        
        
        
    }
}
