/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_3 {
    public static void main(String[] args){
        int count = 0;
        System.out.println( count++);        
       //count++ 
       //分解動作
       //1 先把count輸出 System.out.println(count);
       //2 在把count+=1
       
       //++count
        System.out.println( ++count); 
        //分解動作
       //1 先把count+=1   
       //2 在把count輸出 System.out.println(count);
        
        int value1 = count++;
        System.out.println(value1);
       System.out.println(count);
       
       int i = 1;
       int ans = 2 + i++ + ++i - 3 + i++;
                 //2 + 1 +  3 - 3 + 3;   
       System.out.println("i:"+i);
       System.out.println("ans:"+ans);
       
    }
}
