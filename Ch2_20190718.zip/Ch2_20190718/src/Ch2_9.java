/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
public class Ch2_9 {
    public static void main(String[] args){
        //if else
        Scanner scan = new Scanner(System.in);
        int price = scan.nextInt();
        int budget = 200;
        if (price > budget)
            System.out.println("超過預算");
        else
            System.out.println("預算內");
        //三元運算子
        String msg = price >budget ?"超過預算":"預算內";
        System.out.println(msg);
        
    }
}
