/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_5 {
    public static void main(String[] args){
        int v1 = 27;
        int v2 = 26;
        System.out.println(v1 & v2);
        System.out.println(v1 | v2);
        System.out.println(v1 ^ v2);
        //‭00011011‬ 27
        //‭00011010‬ 26
//        00011011‬
//       00011010‬
//       ______________
//    &    00011010  

   //‭00011011‬ 27
   //‭00011010‬ 26
 //------------- 
// | 00011011 27   
 
  
    //‭00011011‬ 27
    //‭00011010‬ 26     
   //_______________     
   //^00000001  
    }
}
