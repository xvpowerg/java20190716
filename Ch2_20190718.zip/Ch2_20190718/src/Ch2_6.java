/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_6 {
    public static void main(String[] args){
        /*int c1 = 869;
        int c2 = 517;
        int pKey = c1 ^ c2;
        System.out.println(pKey);
        System.out.println(pKey ^ c2);*/
        
        int n1 = 2;
        int k =2;
        System.out.println(n1 << k);//n1 * 2 ^ k
        System.out.println(n1 << 3);
        System.out.println(n1 << 4);
        System.out.println("=================");
        int n2 = 128;
        int z =2;
        System.out.println(n2 >> z);//n2 / 2 ^ z
        System.out.println(n2 >> 3);
        System.out.println(n2 >> 1);
         System.out.println(n2 >> 1);
        //n2 = n2 >> 1;
        System.out.println(n2 >>= 1); // n2 / 2
        System.out.println(n2 >>= 1);
    
    }
}

