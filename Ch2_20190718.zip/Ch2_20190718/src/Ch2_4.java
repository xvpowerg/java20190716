/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author howard
 */
public class Ch2_4 {
    public static void main(String[] args){
        //且 && 兩邊為真才為真　&& 才會有短路現象
        //或 ||　單邊為真才為真 || 才會有短路現象
        //反向 !　唱反調
        //互斥 ^　一真一假才為真
        
        boolean b1 = true;
        boolean b2 = false;
        System.out.println(b1 && b2);
        System.out.println(b1 || b2);
        System.out.println(!b2);
        System.out.println(b2 ^ b1);
        
        int n = 1;
        //且短路特性 左為假不往右
        boolean b3 = ++n > 1 && ++n < 6;
        System.out.println(b3);
        System.out.println(n);
         boolean b4 = ++n < 1 && ++n < 6;
        System.out.println(b4);
        System.out.println(n);
        //或短路特性　左為真不往右
        int k = 1;
       boolean b5 = ++k < 5 || ++k > 3;
       System.out.println(b5);
       System.out.println(k);
        boolean b6 = ++k > 5 || ++k < 3;
       System.out.println(b6);
       System.out.println(k);
       
       
       //| 與 & 不會短路現象
       int g = 1;
        boolean b7 = ++g > 1 & ++g < 6;
        System.out.println(b7);
        System.out.println(g);
         boolean b8 = ++g < 1 & ++g < 6;
        System.out.println(b8);
        System.out.println(g);
       
    }
}
