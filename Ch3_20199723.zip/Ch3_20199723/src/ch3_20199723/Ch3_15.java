/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_15 {

    public static void main(String[] args) {
       int[][] array1 = new int[2][3];
        array1[0][0] = 7;
        array1[0][1] = 5;
        array1[0][2] = 3;
        
        array1[1][0] = 8;
        array1[1][1] = 15;
        array1[1][2] = 9;

       // System.out.println(array1[1][2]);
//        for (int i =0;i<array1.length;i++){
//            for (int k =0;k<array1[i].length;k++){
//                System.out.print(array1[i][k]+" ");
//            }
//            System.out.println();
//        }
        
            for (int[] a1 : array1){
                for (int v : a1){
                    System.out.print(v+" ");
                }
                System.out.println();
            }
        
        
    }
    
}
