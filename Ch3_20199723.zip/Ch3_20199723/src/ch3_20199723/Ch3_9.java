/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*for (int i =1;i<=10;i++){            
            if (i == 5){
                //break;//離開迴圈
                continue;//繼續下一次迴圈
            } 
            System.out.println(i);             
        }*/
        
        Tag1:
        for (int i =1;i<=3;i++){ 
            System.out.println("Step1");
              Tag2:
            for (int k= 1;k<=5;k++){
                 if (k == 3){                   
                    //break Tag1;//離開迴圈
                    continue Tag1;//繼續下一次迴圈                    
                }                  
                System.out.println(k+"Step2");
            }
             System.out.println("Step3");                   
        }
        
        
    }
    
}
