/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_4 {

    public static void main(String[] args) {
        int value = 123______45;        
        switch(value){
            case 12345:
                System.out.println("A1");
                break;
            /*case 123______45:
                System.out.println("A2");
                break;*/
            case 111:
                  System.out.println("A3");
                break;
            default:
                    System.out.println("A4");
                break;
        }
        
        
        
        
    }
    
}
