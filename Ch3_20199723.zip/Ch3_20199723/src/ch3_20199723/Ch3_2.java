/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_2 {

    public static void main(String[] args) {
       //switch case
       //switch 可放入參數 
       //1 可以放入 byte short int char String enum
       System.out.println("1 播放");
       System.out.println("2 暫停");
       System.out.println("3 離開");
     
      //常數
      final int PLAY = 1;
      final int STOP = 2;
      final int EXIT = 3;
      
       int action = PLAY;      
       switch(action){          
           case PLAY:
            System.out.println("播放");
               break;       
           case STOP:
              System.out.println("暫停"); 
               break;
           case EXIT:
             System.out.println("離開");    
               break;
             default:
                System.out.println("錯誤的訊息");
             break;                  
       }
        
        
        
    }
    
}
