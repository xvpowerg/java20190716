/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_1 {
    public static void main(String[] args) {
       // 風力
       //1~6 熱帶氣旋
       //7 8 輕度颱風
       //9 10  中颱風 
       //10以上  強颱    
       
//       int power = 8;
//    
//       if (power >= 1 && power <= 6){
//           System.out.println("熱帶氣旋");
//       }else if(power >= 7 && power <= 8){
//           System.out.println("輕度颱風");
//       }else if(power >= 9 && power <= 10){
//             System.out.println("中颱風");
//       }else{
//             System.out.println("強颱");
//       }
//        
       
       
         int power = 15;        
       if (power < 1){
           System.out.println("錯誤的風力");
       }else if (power >= 1 && power <= 6){
           System.out.println("熱帶氣旋");
       }else if(power <= 8){
           System.out.println("輕度颱風");
       }else if(power <= 10){
             System.out.println("中颱風");
       }else{
             System.out.println("強颱");
       }
        
        
    }
    
}
