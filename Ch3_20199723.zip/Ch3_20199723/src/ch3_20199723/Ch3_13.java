/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;
import java.util.Arrays;
public class Ch3_13 {


    public static void main(String[] args) {
  
       //1 2 3 5 7 8 
       
       /*
       1 找的到　回傳index
       2 找不到　一律負數
         1 比所有的內容都小 一律回傳 -1
         2 比所有的內容都大 (陣列長度 + 1 )*-1
       　3 介於中間 找比被找數大一點的數值的長度 * -1
       
       */
       int[] array = {8,1,3,2,7,5};
       Arrays.sort(array);       
      int index =   Arrays.binarySearch(array, 5);
       System.out.println(index);
      
      int[] array2 = {3,15,7,9,6};
      //3 6 7 9 15
      Arrays.sort(array2);     
      //比所有的內容都小
       index =   Arrays.binarySearch(array2, 2); 
         System.out.println(index); 
       //比所有的內容都大 
       index =   Arrays.binarySearch(array2, 18); 
         System.out.println(index);  
       // 介於中間 
        index =   Arrays.binarySearch(array2, 5); 
         System.out.println(index);
        index =   Arrays.binarySearch(array2, 8); 
         System.out.println(index);  
         
         
    }
    
}
