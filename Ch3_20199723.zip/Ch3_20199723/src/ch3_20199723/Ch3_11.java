/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_11 {
    public static void main(String[] args) {
        //沒有預設的宣告方式 int[]的內容為0
        //float 與 double [] 為0.0
        //char[] 為 空白字元  
        //boolean[] false
        //other[] null
                
      int[] array1= new int[3];
      int array2[] = new int[3];
      
      //有預設值
      int[] array3 = {1,5,6,7,8};      
      int[] array4 = new int[]{1,5,6,8};
        
      
      int targer = 2;
        //找看看有沒有所設定的目標
        //有顯示索引
        //無 顯示找不到
        for (int i =0;i < array4.length;i++){
            if (array4[i] == targer){
                System.out.println("找到了:"+i);
                break;
            }else if(i == array4.length -1){
                System.out.println("沒找到!");
            }
        }
        
    }
    
}
