/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       /* for (int i =2; i<= 9;i++){            
            for (int k = 1;k<=9;k++){
                System.out.printf("%d*%d=%2d ",i,k,i*k);                
            }            
              System.out.println();
        }*/
       int x = 2,y=1;
       while(x <= 9){   
           y = 1;
           while(y <= 9){
               System.out.printf("%d*%d=%2d ",x,y,x*y);
               y++;
           }
           x++;
           System.out.println();
       }
        
    }
    
}
