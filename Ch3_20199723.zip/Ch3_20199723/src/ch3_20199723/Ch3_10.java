/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;
import java.util.Arrays;
/**
 *
 * @author howard
 */
public class Ch3_10 {

    public static void main(String[] args) {
      
        int[] myArray = new int[5];
        myArray[0] =81;
        myArray[1] = 72;
        myArray[2] = 9;  
        myArray[3] = 5;  
        myArray[4] = 67; 
       
       //使用for輪巡
        for (int i =0;i <myArray.length ;i++){
            System.out.print(myArray[i]+" ");
        }
        System.out.println();
       //foreach 
       for(int v : myArray){
           System.out.print(v+" ");
       }
       //Stream + lambda       
       Arrays.stream(myArray).forEach((v)->System.out.println(v+" ") );
       
       int sum= 0;
       for (int v : myArray){
           sum += v;
       }
       System.out.printf("%d:%d",myArray.length,sum);
       
       
    }
    
}
