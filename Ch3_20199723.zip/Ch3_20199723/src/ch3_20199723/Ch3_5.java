/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_5 {
       static int step1(){
           System.out.println("step1");
           return 1;
       }       
        static boolean step2(){
            System.out.println("step2");
            return true;
        }    
        static void step3(int i){
            System.out.println(i+":step3");
        }
        static void step4(){
            System.out.println("step4");
        }                
    public static void main(String[] args) {      
        
        /*for ( int i =1 ; i<=10 ; i++ ){
            System.out.println(i);
        }*/        
        for (int k = step1(); k <= 5 && step2();k++,step4()){
             step3(k);
        }        
        
    }
    
}
