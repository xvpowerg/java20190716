/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //null只能用在非基本型態
        
        String name = null;        
        switch(name){
            case "Vivin":
                System.out.println("助理工程師");
                break;
            case "Lindy":
                System.out.println("PM");
                break; 
            case "Ken":
                System.out.println("資深工程師");
                break;
            default:
                System.out.println("錯誤的姓名");
                break;
        }
        
       
    }
    
}
