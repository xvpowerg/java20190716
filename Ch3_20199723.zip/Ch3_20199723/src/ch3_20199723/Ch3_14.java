/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;
import java.util.Arrays;
import java.util.ArrayList;
public class Ch3_14 {
    public static void main(String[] args) {
        int[] array1 = {1,5,6,8,9,3,2,7};
        int[] copyArray = Arrays.copyOf(array1,5);
        for (int v : copyArray){
            System.out.print(v+" ");
        }
          System.out.println("======================");
        copyArray =  Arrays.copyOfRange(array1, 1, 6);
          for (int v : copyArray){
            System.out.print(v+" ");
        }
            System.out.println("======================");
          int[] array2 = new int[90000];
          Arrays.fill(array2, 100);
          System.out.println(array2[0]);
          String[] strArray = new String[90000];
          Arrays.fill(strArray, "");
          System.out.println(strArray[0].isEmpty());
         
          ArrayList list = new ArrayList();
          list.add("Ken");
          list.add("Vivin");
          list.add("Lindy");
          list.add("Join");
          for (Object obj : list){
              System.out.print(obj+" ");
          }
          
    }
    
}
