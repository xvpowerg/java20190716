/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_16 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int[][] array2x3 = new int[2][3];
       int[] array2x2[] = new int[2][2];
       int array2x5[][] = new int[2][5];
       
       int[][] array2 = { {2,5,6},
                          {7,8,9}   };
       
       for (int i= 0; i< array2.length ;i++){
           for (int k =0;k < array2[i].length;k++){
               System.out.print(array2[i][k]+" ");
           }
           System.out.println();
       }
       
        int[][] array3= { {2,5,6},
                          {7,8}   };
        
            for (int i= 0; i< array3.length ;i++){
           for (int k =0;k < array3[i].length;k++){
               System.out.print(array3[i][k]+" ");
           }
           System.out.println();
       }
    }
    
}
