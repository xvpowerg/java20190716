/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;

/**
 *
 * @author howard
 */
public class Ch3_6 {
    public static void main(String[] args) {
//        int i =1;
//        while(i <= 100){
//            System.out.println(i++);
//        }

        int n= 20;
        //1 * 2 * 3 * 4 * 5
        int k =1;
        long ans = 1;
        while(k <= n){
            ans *= k++;                        
        }
        System.out.printf("!%d=%d",n,ans);
        
        
    }
    
}
