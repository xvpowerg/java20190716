/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch3_20199723;
import java.util.Arrays;
import java.util.Random;
/**
 *
 * @author howard
 */
public class Ch3_12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
     int array4[] = new int[90000000];   
     array4[90000000 - 1] = 2;
       int targer = 2;
        //找看看有沒有所設定的目標
        //有顯示索引
        //無 顯示找不到
        double start = System.nanoTime();
//        for (int i =0;i < array4.length;i++){
//            if (array4[i] == targer){
//                System.out.println("找到了:"+i);
//                break;
//            }else if(i == array4.length -1){
//                System.out.println("沒找到!");
//            }
//        } 
        //二分搜尋法
         /*int index =  Arrays.binarySearch(array4, targer);
         System.out.println("index:"+index);
        double end = System.nanoTime();  
        System.out.println( (end - start) / 1_000_000  );*/
         //必須要排序 
         //由小到大排序遞增排序asc  
        Random ran = new Random();
        
        //int[] array5 = {7,8,9,2,3,1};
        int[] array5 = new int[90000];
        for (int i =0;i< array5.length;i++){
            array5[i] = ran.nextInt(900000000);
        }
             
        System.out.println("開始排序....");
         double start2 = System.nanoTime(); 
          Arrays.sort(array5);
//         for (int i =0  ;  i < array5.length ; i++ ){             
//             for (int k = i+1;k < array5.length;k++){                 
//                 if (array5[k] < array5[i]){
//                     int tmp = array5[k];
//                     array5[k] = array5[i];
//                      array5[i] = tmp;                     
//                 }                 
//             }             
//         }
          double end2 = System.nanoTime();  
         System.out.println( (end2 - start2) / 1_000_000  ); 
//        for(int v1 : array5){
//            System.out.print(v1+" ");
//        }
        
        
        
    }
    
}
