/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;

import java.util.Iterator;

public class Ch8_5 {
    
    public static void main(String[] args) {
           MyOrders myOrders = new MyOrders();
           myOrders.addOrder("Ken 第一筆訂單");
           myOrders.addOrder("Vivin 第二筆訂單");
           myOrders.addOrder("Lindy 第三筆訂單");
//           System.out.println(myOrders.getOrder(0));
//           System.out.println(myOrders.getOrder(1));
//           System.out.println(myOrders.size());
           
//           for (int i =0;i<myOrders.size();i++){
//               System.out.println(myOrders.getOrder(i));
//           }
//           
//          Iterator<String> it = myOrders.iterator();
//          while(it.hasNext()){
//              System.out.println(it.next());
//          }

//            for (String order : myOrders){
//                    System.out.println(order);
//            }

        myOrders.forEach((order)->System.out.println(order));
           //System.out.println(myOrders.getOrder(2));
    }
    
}
