/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;
import java.util.function.Consumer;
import java.util.function.Function;
/**
 *
 * @author howard
 */
public class Ch8_1 {
    //
      static void showArray(String[] array,Consumer<String> consumer){
          for (String v : array){
              if (consumer != null){
                  consumer.accept(v);
              }else{
                  System.out.println(v);
              }              
          }
      }  
     
      static Item[] stringArrayToItem(String[] names,Function<String,Item> function){
          Item[] itemArray = new Item[names.length];
            
          for (int i = 0;i<names.length;i++){
                itemArray[i] = function.apply(names[i]);
          }
          
          return itemArray;
      }
      

    public static void main(String[] args) {
       //Consumer<T>
       //Function<T,R>
       //Predicate<T>
       //Supplier<T>
       //UnaryOperator<T>
        String[] names = {"Ken","Iris","Vivin"};
       showArray(names,new Consumer<String>(){       
            public void accept(String v){
                    System.out.println("姓名:"+v);
            }
       }); 
       System.out.println("======================");
       //標準Lambda
       showArray(names,(v)->System.out.print(v+" ")); 
       System.out.println("");
      System.out.println("======================");
     // 參數類型可以更明確      
     showArray(names,(String v)->System.out.print(v+" ")); 
        System.out.println("");
       System.out.println("======================");
    // 因為只有一個參數所以可簡化
     showArray(names, v->System.out.print(v+" ")); 
     //注意以上lambda都沒有分號，因為沒有大誇號
       System.out.println("");
       System.out.println("======================");
      //練習加上大誇號
        showArray(names, v->{
            if (v.length() > 3){
                 System.out.print(v+" "); 
            }
          });  
       System.out.println("");
       System.out.println("======================");   
        
    Item[] items1 =   stringArrayToItem (names,new Function<String,Item>(){
           public Item apply(String name){
               if (name.length() <= 3){
                   name += "長度不大於三";
               }
               Item item = new Item(name);
               return item;
           }            
      });
    
    for (Item i1 : items1){
        System.out.print(i1+" ");
    }
      System.out.println("");
       System.out.println("======================");       
        //lambda 寫法
        Item[] items2 =   stringArrayToItem (names,(v)->new Item(v));
          for (Item i2 : items2){
            System.out.print(i2+" ");
        }
           System.out.println("");
       System.out.println("======================");    
       //MethodReference 創建Item
       Item[] items3 =   stringArrayToItem (names,Item::new);
         for (Item i3 : items3){
            System.out.print(i3+" ");
        }  
         
    }
    
}
