/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;

/**
 *
 * @author howard
 */
public class Ch8_3 { 
    
    enum Fruit{
        Apple("蘋果"){        
         public String toString(){
             return "富士:"+super.toString();
         }   
        },
        Banana("香蕉"),
        Charry("櫻桃");
    private String name;    
      private Fruit(){
          
      }  
     private Fruit(String name){
         this.name = name;
     } 
//      public String toString(){
//          return "水果:"+super.toString();
//      }
     public String toString(){
         return "水果:"+name;
     }
    }
    public static void main(String[] args) {
        
//        System.out.println(Fruit.Apple);
//        Fruit myFruit = Fruit.Charry;
//        switch(myFruit){
//            case Apple:
//                System.out.println("Apple 100元");
//                break;
//            case Banana:
//                System.out.println("Banana 50元");
//                break;
//            case Charry:
//                System.out.println("Charry 160元");
//                break;
//        }
        Fruit f1 = Fruit.valueOf("Apple");
        
        System.out.println(f1);
        Fruit[] fruits =  Fruit.values();
        for (Fruit f : fruits ){
            System.out.println(f);
        }
        //java.lang.IllegalArgumentException
       // Fruit f2 = Fruit.valueOf("Kiwi");
        
       Fruit apple = Fruit.Apple;
        Fruit charry = Fruit.Charry;
       System.out.println(apple.name());
       System.out.println(apple.ordinal());
       System.out.println(apple.compareTo(charry));   
        
    }
    
}
