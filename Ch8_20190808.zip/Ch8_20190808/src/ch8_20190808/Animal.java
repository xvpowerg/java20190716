/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;

public enum  Animal {
    Dog("狗狗"),
    Cat("貓貓"),
    Tiger("老虎");
    private String type;
    private Animal(){
        
    }
    private Animal(String type){
        this.type = type;
    }
    
    public String toString(){
        return type;
    }
}
