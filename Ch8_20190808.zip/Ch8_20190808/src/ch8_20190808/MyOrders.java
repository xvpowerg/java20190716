/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;
import java.util.Iterator;
public class MyOrders implements Iterable<String> {
    private int maxSize = 500;
    private int index = -1;
   private String[] orders = new String[maxSize];  
   
   private class OrderIterator implements Iterator<String>{
       private MyOrders myOrders;
       private int maxSize = -1;
       private int currentIndex = -1;
       public OrderIterator(MyOrders myOrders){
           this.myOrders = myOrders;
           maxSize = myOrders.size();
       }
       public boolean hasNext(){           
           return currentIndex < maxSize - 1;
       }
       public String next(){
           return myOrders.getOrder(++currentIndex);
       }
   }
   
   public Iterator<String> iterator(){
       return new OrderIterator(this);
   }
   
   public void addOrder(String order){     
       orders[++index] = order;
   }
   public int size(){
       return index + 1;
   }
   public String getOrder(int index){
       if (index < 0 || index > this.index ){
           throw new IllegalArgumentException("錯誤的index");
       }
      return orders[index];
   }
   
   
   
}
