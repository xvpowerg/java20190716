/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;

/**
 *
 * @author howard
 */
public class Ch8_4 {
    
    static void showAnimal(Animal animal){
        switch(animal){
            case Dog:
             System.out.println("狗狗");
              break;  
            case Cat:
                System.out.println("貓貓");
                break;
            case Tiger:
                System.out.println("老虎");
                break;
        }
        
    }
  
    public static void main(String[] args) {
        Ch8_3.Fruit banana = Ch8_3.Fruit.Banana;
        System.out.println(banana);
        
        Animal tiger = Animal.Dog;
        System.out.println(tiger);        
        showAnimal(Animal.Cat);
        
        
        System.out.println(tiger);
        
         Ch8_3.Fruit apple = Ch8_3.Fruit.Apple;
        System.out.println(apple);
        
    }
    
}
