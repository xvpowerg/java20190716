/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
public class Ch8_2 {
   
 
    
    static boolean findArray(String[] names,Predicate<String> predicate){
        for (String name : names){
            if (predicate.test(name)){
                    return true;     
            }           
        }
        return false;
    }
    
   static boolean findKen(String str){
       return str.equals("Ken");
   }
   
    static Object objectNotNull(Object obj,
                    Supplier<? extends RuntimeException> excSpplier){
        if (obj == null){
            throw excSpplier.get();
        }
        return obj;
    }
    
    static Collection arrayToCollection(String[]array,
            Supplier<? extends Collection<String>> collection ){
        Collection<String> collect = collection.get();
        for (String value : array){
             collect.add(value);
        }       
        return collect;
    }
    static void repleaceAll(String[] array,UnaryOperator<String> uo){
        
        for (int i =0;i< array.length;i++){
            String value = array[i];
            array[i] = uo.apply(value);
        }
        
    }
    
    
      
    
    public static void main(String[] args) {
       String[] names = {"Join","Lindy","Ken","Vivin"};
  boolean strLen3 =   findArray(names,new Predicate<String>(){        
            public boolean test(String v){
                    if (v.length() == 3){
                        return true;
                    }
                return false;
            }            
    } );
  System.out.println(strLen3);
 System.out.println("======================");
 //lambda 的寫法
  boolean strLenGr5 =  findArray(names,n->n.length() > 5);
  System.out.println(strLenGr5);
  System.out.println("======================");
  //Method Reference
  boolean cnaFindKen =  findArray(names,Ch8_2::findKen);
 System.out.println(cnaFindKen); 
          //Predicate<T>
       //Supplier<T>
       //UnaryOperator<T>
   String value = "Howard";     
   Object checkValue = objectNotNull(value,
           ()-> new IllegalArgumentException("value不可為Null"));
   System.out.println(checkValue);
   System.out.println("===========================");
       Collection coll =  arrayToCollection(names, ()->new ArrayList());
       coll.remove("Ken");
       coll.forEach(System.out::println);
  System.out.println("===========================");
  
  String[] copyArray  = Arrays.copyOf(names,names.length);
  repleaceAll(copyArray,new UnaryOperator<String>(){
                    public String apply(String name){                        
                        return  "Title:"+name+".";                        
                    }                    
                });
     for (String name :copyArray)  {
         System.out.println(name);
     }
     System.out.println("===========================");
    repleaceAll(names,n->"name:"+n); 
     Arrays.stream(names).forEach(System.out::println);
    }
    
}
