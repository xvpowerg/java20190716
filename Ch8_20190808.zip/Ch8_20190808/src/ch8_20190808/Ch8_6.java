/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch8_20190808;
import java.util.ArrayList;
public class Ch8_6 {

    
    public static void main(String[] args) {
       ArrayList<String> list = new ArrayList<>();
       list.add("Ken");
       list.add("Vivin");
       list.add("Lindy");
       list.add("Sean");
       list.forEach(System.out::println);   
       System.out.println("=============================");
       list.add(1, "Iris");
       list.forEach(System.out::println);
      System.out.println("=============================");  
      ArrayList<String> nameList = new ArrayList<>();
      nameList.add("Howard");
      nameList.add("Neor");
       list.addAll(nameList);
     System.out.println("=============================");  
        for (int i =0;i<list.size();i++){
            System.out.println(list.get(i));
        }
    }
    
}
